<!DOCTYPE html>
<html lang="en-US"
	prefix="og: https://ogp.me/ns#" >
<head>
	<meta charset="UTF-8" >
	<meta name="viewport" id="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />

	<link rel='dns-prefetch' href='//siraplimau.com' />

	
	<link rel="shortcut icon" href="https://media.siraplimau.com/wp-content/uploads/2018/12/favicon-32x32.png" />	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="https://siraplimau.com/feed/" />
	<link rel="alternate" type="text/xml" title="RSS .92" href="https://siraplimau.com/feed/rss/" />
  <link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="https://siraplimau.com/feed/atom/" />
  <link rel="stylesheet" href="https://policy.revasia.com/cookie.consent.css" />
	<link rel="pingback" href="https://siraplimau.com/wp/xmlrpc.php" />

	
		<meta property="og:description" content="Gaya Hidup Famili Moden" />
	
	
	  <meta name="section" content="others" />
	
	<title>Page not found &#8211; SirapLimau.com</title>

		<!-- All in One SEO 4.0.16 -->
		<meta name="robots" content="noindex"/>
		<link rel="canonical" href="https://siraplimau.com/signals/iwl.js/" />
		<script type="application/ld+json" class="aioseo-schema">
			{"@context":"https:\/\/schema.org","@graph":[{"@type":"WebSite","@id":"https:\/\/siraplimau.com\/#website","url":"https:\/\/siraplimau.com\/","name":"SirapLimau.com","description":"Gaya Hidup Famili Moden","publisher":{"@id":"https:\/\/siraplimau.com\/#organization"}},{"@type":"Organization","@id":"https:\/\/siraplimau.com\/#organization","name":"SirapLimau.com","url":"https:\/\/siraplimau.com\/","sameAs":["https:\/\/www.facebook.com\/mysiraplimau"]},{"@type":"BreadcrumbList","@id":"https:\/\/siraplimau.com\/signals\/iwl.js\/#breadcrumblist","itemListElement":[{"@type":"ListItem","@id":"https:\/\/siraplimau.com\/#listItem","position":"1","item":{"@id":"https:\/\/siraplimau.com\/#item","name":"Home","description":"Gaya Hidup Famili Moden","url":"https:\/\/siraplimau.com\/"},"nextItem":"https:\/\/siraplimau.com\/signals\/iwl.js\/#listItem"},{"@type":"ListItem","@id":"https:\/\/siraplimau.com\/signals\/iwl.js\/#listItem","position":"2","item":{"@id":"https:\/\/siraplimau.com\/signals\/iwl.js\/#item","name":"Not Found","url":"https:\/\/siraplimau.com\/signals\/iwl.js\/"},"previousItem":"https:\/\/siraplimau.com\/#listItem"}]}]}
		</script>
		<!-- All in One SEO -->

<link rel='dns-prefetch' href='//tags.crwdcntrl.net' />
<link rel='dns-prefetch' href='//bcp.crwdcntrl.net' />
<link rel='dns-prefetch' href='//netdna.bootstrapcdn.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="SirapLimau.com &raquo; Feed" href="https://siraplimau.com/feed/" />
		<script type="72b443237b292a11638577a2-text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/siraplimau.com\/wp\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.6.2"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='https://siraplimau.com/wp/wp-includes/css/dist/block-library/style.min.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='wp-components-css'  href='https://siraplimau.com/wp/wp-includes/css/dist/components/style.min.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='wp-editor-font-css'  href='https://fonts.googleapis.com/css?family=Noto+Serif%3A400%2C400i%2C700%2C700i&#038;ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-editor-css'  href='https://siraplimau.com/wp/wp-includes/css/dist/block-editor/style.min.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='wp-nux-css'  href='https://siraplimau.com/wp/wp-includes/css/dist/nux/style.min.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='wp-editor-css'  href='https://siraplimau.com/wp/wp-includes/css/dist/editor/style.min.css?ver=5.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='mux_video_block_style-css'  href='https://siraplimau.com/app/plugins/ilab-media-tools/public/blocks/mediacloud-mux.blocks.style.css' type='text/css' media='all' />
<link rel='stylesheet' id='lightning-tag-css'  href='https://siraplimau.com/app/plugins/lightning-tag-plugin-wordpress/public/css/lightning-tag-public.css?ver=1.0.0' type='text/css' media='all' />
<link rel='preconnect' id='preconnect_link_tags-css'  href='https://tags.crwdcntrl.net'   />
<link rel='preconnect' id='preconnect_link_bcp-css'  href='https://bcp.crwdcntrl.net'   />
<link rel='stylesheet' id='widgetopts-styles-css'  href='https://siraplimau.com/app/plugins/widget-options/assets/css/widget-options.css' type='text/css' media='all' />
<link rel='stylesheet' id='mvp-reset-css'  href='https://siraplimau.com/app/themes/flex-mag/css/reset.css?ver=201812271620' type='text/css' media='all' />
<link rel='stylesheet' id='mvp-fontawesome-css'  href='//netdna.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.css?ver=201812271620' type='text/css' media='all' />
<link rel='stylesheet' id='mvp-style-css'  href='https://siraplimau.com/app/themes/flex-mag/style.css?ver=201812271620' type='text/css' media='all' />
<!--[if lt IE 10]>
<link rel='stylesheet' id='mvp-iecss-css'  href='https://siraplimau.com/app/themes/flex-mag/css/iecss.css?ver=201812271620' type='text/css' media='all' />
<![endif]-->
<link rel='stylesheet' id='mvp-media-queries-css'  href='https://siraplimau.com/app/themes/flex-mag/css/media-queries.css?ver=201812271620' type='text/css' media='all' />
<link rel='stylesheet' id='mvp-style-override-css'  href='https://siraplimau.com/app/themes/flex-mag/css/override.css?ver=201812271620' type='text/css' media='all' />
<script type="72b443237b292a11638577a2-text/javascript" src='https://siraplimau.com/wp/wp-includes/js/jquery/jquery.min.js?ver=3.5.1' id='jquery-core-js'></script>
<script type="72b443237b292a11638577a2-text/javascript" src='https://siraplimau.com/wp/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type="72b443237b292a11638577a2-text/javascript" id='lightning-tag-js-extra'>
/* <![CDATA[ */
var lightningtag_data = {"traffic":"siraplimau.com\/wp","lotame_id":"11143","sitename":"siraplimau.com","author":"","title":"","categories":[],"tags":""};
/* ]]> */
</script>
<script type="72b443237b292a11638577a2-text/javascript" src='https://siraplimau.com/app/plugins/lightning-tag-plugin-wordpress/public/js/lightning-tag-public.js?ver=1.0.0' id='lightning-tag-js'></script>
<script type="72b443237b292a11638577a2-text/javascript" async="async" src='https://tags.crwdcntrl.net/lt/c/11143/lt.min.js?ver=5.6.2' id='lotame_script-js'></script>
<link rel="https://api.w.org/" href="https://siraplimau.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://siraplimau.com/wp/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://siraplimau.com/wp/wp-includes/wlwmanifest.xml" /> 
			<meta property="fb:pages" content="446127318757289" />
			
<style type='text/css'>

@import url(//fonts.googleapis.com/css?family=Oswald:400,700|Lato:400,700|Work+Sans:900|Montserrat:400,700|Open+Sans:800|Playfair+Display:400,700,900|Quicksand|Raleway:200,400,700|Roboto+Slab:400,700|Work+Sans:100,200,300,400,500,600,700,800,900|Montserrat:100,200,300,400,500,600,700,800,900|Work+Sans:100,200,300,400,400italic,500,600,700,700italic,800,900|Lato:100,200,300,400,400italic,500,600,700,700italic,800,900|Montserrat:100,200,300,400,500,600,700,800,900&subset=latin,latin-ext,cyrillic,cyrillic-ext,greek-ext,greek,vietnamese);

#wallpaper {
	background: url() no-repeat 50% 0;
	}
body,
.blog-widget-text p,
.feat-widget-text p,
.post-info-right,
span.post-excerpt,
span.feat-caption,
span.soc-count-text,
#content-main p,
#commentspopup .comments-pop,
.archive-list-text p,
.author-box-bot p,
#post-404 p,
.foot-widget,
#home-feat-text p,
.feat-top2-left-text p,
.feat-wide1-text p,
.feat-wide4-text p,
#content-main table,
.foot-copy p,
.video-main-text p {
	font-family: 'Lato', sans-serif;
	}

a,
a:visited,
.post-info-name a {
	color: #F1197C;
	}

a:hover {
	color: #999999;
	}

.fly-but-wrap,
span.feat-cat,
span.post-head-cat,
.prev-next-text a,
.prev-next-text a:visited,
.prev-next-text a:hover {
	background: #F1197C;
	}

.fly-but-wrap {
	background: #F1197C;
	}

.fly-but-wrap span {
	background: #ffffff;
	}

.woocommerce .star-rating span:before {
	color: #F1197C;
	}

.woocommerce .widget_price_filter .ui-slider .ui-slider-range,
.woocommerce .widget_price_filter .ui-slider .ui-slider-handle {
	background-color: #F1197C;
	}

.woocommerce span.onsale,
.woocommerce #respond input#submit.alt,
.woocommerce a.button.alt,
.woocommerce button.button.alt,
.woocommerce input.button.alt,
.woocommerce #respond input#submit.alt:hover,
.woocommerce a.button.alt:hover,
.woocommerce button.button.alt:hover,
.woocommerce input.button.alt:hover {
	background-color: #F1197C;
	}

span.post-header {
	border-top: 4px solid #F1197C;
	}

#main-nav-wrap,
nav.main-menu-wrap,
.nav-logo,
.nav-right-wrap,
.nav-menu-out,
.nav-logo-out,
#head-main-top {
	-webkit-backface-visibility: hidden;
	background: #F1197C;
	}

nav.main-menu-wrap ul li a,
.nav-menu-out:hover ul li:hover a,
.nav-menu-out:hover span.nav-search-but:hover i,
.nav-menu-out:hover span.nav-soc-but:hover i,
span.nav-search-but i,
span.nav-soc-but i {
	color: #ffffff;
	}

.nav-menu-out:hover li.menu-item-has-children:hover a:after,
nav.main-menu-wrap ul li.menu-item-has-children a:after {
	border-color: #ffffff transparent transparent transparent;
	}

.nav-menu-out:hover ul li a,
.nav-menu-out:hover span.nav-search-but i,
.nav-menu-out:hover span.nav-soc-but i {
	color: #fdacc8;
	}

.nav-menu-out:hover li.menu-item-has-children a:after {
	border-color: #fdacc8 transparent transparent transparent;
	}

.nav-menu-out:hover ul li ul.mega-list li a,
.side-list-text p,
.row-widget-text p,
.blog-widget-text h2,
.feat-widget-text h2,
.archive-list-text h2,
h2.author-list-head a,
.mvp-related-text a {
	color: #222222;
	}

ul.mega-list li:hover a,
ul.side-list li:hover .side-list-text p,
ul.row-widget-list li:hover .row-widget-text p,
ul.blog-widget-list li:hover .blog-widget-text h2,
.feat-widget-wrap:hover .feat-widget-text h2,
ul.archive-list li:hover .archive-list-text h2,
ul.archive-col-list li:hover .archive-list-text h2,
h2.author-list-head a:hover,
.mvp-related-posts ul li:hover .mvp-related-text a {
	color: #999999 !important;
	}

span.more-posts-text,
a.inf-more-but,
#comments-button a,
#comments-button span.comment-but-text {
	border: 1px solid #F1197C;
	}

span.more-posts-text,
a.inf-more-but,
#comments-button a,
#comments-button span.comment-but-text {
	color: #F1197C !important;
	}

#comments-button a:hover,
#comments-button span.comment-but-text:hover,
a.inf-more-but:hover,
span.more-posts-text:hover {
	background: #F1197C;
	}

nav.main-menu-wrap ul li a,
ul.col-tabs li a,
nav.fly-nav-menu ul li a,
.foot-menu .menu li a {
	font-family: 'Montserrat', sans-serif;
	}

.feat-top2-right-text h2,
.side-list-text p,
.side-full-text p,
.row-widget-text p,
.feat-widget-text h2,
.blog-widget-text h2,
.prev-next-text a,
.prev-next-text a:visited,
.prev-next-text a:hover,
span.post-header,
.archive-list-text h2,
#woo-content h1.page-title,
.woocommerce div.product .product_title,
.woocommerce ul.products li.product h3,
.video-main-text h2,
.mvp-related-text a {
	font-family: 'Montserrat', sans-serif;
	}

.feat-wide-sub-text h2,
#home-feat-text h2,
.feat-top2-left-text h2,
.feat-wide1-text h2,
.feat-wide4-text h2,
.feat-wide5-text h2,
h1.post-title,
#content-main h1.post-title,
#post-404 h1,
h1.post-title-wide,
#content-main blockquote p,
#commentspopup #content-main h1 {
	font-family: 'Work Sans', sans-serif;
	}

h3.home-feat-title,
h3.side-list-title,
#infscr-loading,
.score-nav-menu select,
h1.cat-head,
h1.arch-head,
h2.author-list-head,
h3.foot-head,
.woocommerce ul.product_list_widget span.product-title,
.woocommerce ul.product_list_widget li a,
.woocommerce #reviews #comments ol.commentlist li .comment-text p.meta,
.woocommerce .related h2,
.woocommerce div.product .woocommerce-tabs .panel h2,
.woocommerce div.product .product_title,
#content-main h1,
#content-main h2,
#content-main h3,
#content-main h4,
#content-main h5,
#content-main h6 {
	font-family: 'Work Sans', sans-serif;
	}

</style>
	
<style type="text/css">


.post-cont-out,
.post-cont-in {
	margin-right: 0;
	}








</style>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-7290637544752706" crossorigin="anonymous" type="72b443237b292a11638577a2-text/javascript"></script>
<script async src="https://securepubads.g.doubleclick.net/tag/js/gpt.js" type="72b443237b292a11638577a2-text/javascript"></script><script type="72b443237b292a11638577a2-text/javascript">window.googletag = window.googletag || {cmd: []};googletag.cmd.push(function() {googletag.defineSlot('/1009103/SR_Andbeyond_Pixel', [1, 1], 'div-gpt-ad-1583725217210-0').addService(googletag.pubads());googletag.pubads().enableSingleRequest();googletag.pubads().collapseEmptyDivs();googletag.enableServices();});</script>
<style>
  #div-gpt-ad-1493804392438-2,
  #div-gpt-ad-1565946683967-0{
      text-align: center;
      margin: 20px auto !important;
  }
  #feat-wide-main{
      margin-top: 10px;
  }
  @media (max-width: 992px) {
      #div-gpt-ad-1493804392438-0 {
          display: none;
      }
  }

  #background-sidebar-wrap {display: none;}
  body.no-ads div.unruly_in_article_placement {
   display: none !important;
  }
    body.no-ads div#banner {display: none !important;}
  #wsbanner, #wsbanner2 {display: none;}
  @media screen and (max-width: 991px){
    #wsbanner iframe {
        height: 246px !important;
    }
    #wsbanner2 iframe {
        height: 134px !important;
    }
  }
  @media screen and (max-width: 479px) {
    #wsbanner iframe {
      height: 246px !important;
    }
    #wsbanner2 iframe {
      height: 136px !important;
    } 
    #leaderboard {position: unset !important;}
  }
  
  @media screen and (max-width: 380px) {
    #wsbanner iframe {
      height: 223px !important;
    }
    #wsbanner2 iframe {
      height: 110px !important;
    } 
    #leaderboard {position: unset !important;}
  }
  	.admin-bar #wsbanner2 {
      top: 96px !important;
    }
    .post-tags a[href*="/tag/no-ads"] {
      display: inline !important;
    }
</style>
<!-- Begin Dable Script / For inquiries, visit http://dable.io -->
<!--script>
(function(d,a,b,l,e,_) {
d[b]=d[b]||function(){(d[b].q=d[b].q||[]).push(arguments)};e=a.createElement(l);
e.async=1;e.charset='utf-8';e.src='//static.dable.io/dist/plugin.min.js';
_=a.getElementsByTagName(l)[0];_.parentNode.insertBefore(e,_);
})(window,document,'dable','script');
dable('setService', 'siraplimau.com');
dable('sendLogOnce');
</script-->
<!-- End Dable Script / For inquiries, visit http://dable.io -->

<script type="72b443237b292a11638577a2-text/javascript">
(function($) {
var width = document.documentElement.clientWidth;
if (width > 992) {
  console.log('Desktop');
} else {
  console.log('Mobile');
}
 
$('.dable-content-wrapper').append(`
<!-- Begin Dable responsive / For inquiries, visit http://dable.io -->
<div id="dablewidget_GlGggG6l_zlvmmeG7" data-widget_id-pc="GlGggG6l" data-widget_id-mo="zlvmmeG7">
<script>
(function(d,a){d[a]=d[a]||function(){(d[a].q=d[a].q||[]).push(arguments)};}(window,'dable'));
dable('renderWidgetByWidth', 'dablewidget_GlGggG6l_zlvmmeG7');
<\/script>
</div>
<!-- End responsive / For inquiries, visit http://dable.io -->
`);
})(jQuery);
</script>

<script type="72b443237b292a11638577a2-text/javascript">
	if (jQuery("body").hasClass('no-ads')) {
    	jQuery('div[id^="div-gpt"], .adsbygoogle, .mgbox, #myads, .code-block, .teads-inread').remove(); 
	}
</script>

		<style type="text/css" id="wp-custom-css">
			nav.fly-nav-menu {
	overflow: scroll !important;
}
@media(min-width:767px){
	.read-more-btn{
		display: none;
	}
}
.recommended-stories .rstory-cards > img {
	width: 100%;
}
.recommended-stories > a{
	color: black;
	font-family: 'Montserrat',sans-serif;
	font-weight: 400;
	font-size:.9rem ;
}

.widget_wpb_recommendation_widget .side-list-title{
	padding-bottom: 5px;
}
@media(max-width: 479px){
	.rstory-cards .feat-widget-text{
		width :100% !important ;
		padding-top: 10px !important; 
	}
}
.blog-widget-list .widget-ad [id^=div-gpt-ad]:first-of-type{
	padding-bottom :18px;
}
#background-sidebar-wrap{
	top:auto;
}
@media(max-width: 479px){
	 #banner{
		margin-top:60px !important;
	}
}
.radio-logo {
    width: 45px;
    margin-right: 15px;
}

.radio-logo.small {
    width: 23px;
    margin-right: 25px;
    margin-left: 10px;
}

.nav-right-wrap {
	width: max-content;
}		</style>
		<style>
.ai-viewports                 {--ai: 1;}
.ai-viewport-3                { display: none !important;}
.ai-viewport-2                { display: none !important;}
.ai-viewport-1                { display: inherit !important;}
.ai-viewport-0                { display: none !important;}
@media (min-width: 768px) and (max-width: 979px) {
.ai-viewport-1                { display: none !important;}
.ai-viewport-2                { display: inherit !important;}
}
@media (max-width: 767px) {
.ai-viewport-1                { display: none !important;}
.ai-viewport-3                { display: inherit !important;}
}
</style>

	<script type="72b443237b292a11638577a2-text/javascript">
    window.dfpTargetingParams = {};
    window.dfpTargetingParams.pos = "others";
    window.dfpTargetingParams.section = ["others"];
    window.dfpTargetingParams.tags = ["others"];

  </script>

	<!-- Lotame ad tag-->
<!-- <script type="text/javascript" src="//ad.crwdcntrl.net/5/c=7268/pe=y/var=lotauds"></script>
<script src="//tags.crwdcntrl.net/c/11143/cc_af.js"></script> -->
<!-- End Lotame ad tag -->

<script type="72b443237b292a11638577a2-text/javascript">
  var PWT={}; //Initialize Namespace
  var googletag = googletag || {};
  googletag.cmd = googletag.cmd || [];
</script>

<script type="72b443237b292a11638577a2-text/javascript">
  PWT.jsLoaded = function(){ //PubMatic pwt.js on load callback is used to load GPT
    (function() {
      var gads = document.createElement('script');
      var useSSL = 'https:' == document.location.protocol;
      gads.src = (useSSL ? 'https:' : 'http:') + '//www.googletagservices.com/tag/js/gpt.js';
      var node = document.getElementsByTagName('script')[0];
      node.parentNode.insertBefore(gads, node);
    })();
  };

  (function() {
    var purl = window.location.href;
    var url = '//ads.pubmatic.com/AdServer/js/pwt/121793/1321';
    var profileVersionId = '';

    if(purl.indexOf('pwtv=')>0){
      var regexp = /pwtv=(.*?)(&|$)/g;
      var matches = regexp.exec(purl);
      if(matches.length >= 2 && matches[1].length > 0){
        profileVersionId = '/'+matches[1];
      }
    }

    var wtads = document.createElement('script');
    wtads.async = true;
    wtads.type = 'text/javascript';
    wtads.src = url+profileVersionId+'/pwt.js';
    var node = document.getElementsByTagName('script')[0];

    node.parentNode.insertBefore(wtads, node);
  })();
</script>

<script type="72b443237b292a11638577a2-text/javascript">
  var width = document.documentElement.clientWidth;
  var size;
  var sizes;
  var dfpTargetingParams = window.dfpTargetingParams || {};

  if (width < 992) {
      size = [320, 50]; // mobile
      sizes = [[320,50],[320,100]];
  } else {
      size = [728, 90]; // desktop
      sizes = [[728,90],[970,90],[970,250]]
  }

  // For InSkin
  var inskinTargeting;

  if (width > 1230) {
    inskinTargeting = 'desktop';
  } else if (width >= 375 && width <= 600) {
    inskinTargeting = 'mobile';
  } else if (width > 600 && width <= 1229) {
    inskinTargeting = 'tablet';
  }

  /*if (typeof lotauds === "object"){
      var obj = lotauds.Profile.Audiences["Audience"],
          lotaudsList=[];

      for (var p in obj) {
          if ( obj.hasOwnProperty(p) ) {
              lotaudsList.push(obj[p]["abbr"]);
          }
      }
  }

  if (typeof lotauds === "object"){
    var obj = lotauds.Profile.Audiences["Audience"],
        lotaudsList = [];

    for (var p in obj) {
      if( obj.hasOwnProperty(p) ) {
        lotaudsList.push(obj[p]["abbr"]);
      }
    }
  }*/

  googletag.cmd.push(function() {
    // googletag.defineSlot('/1009103/SR_Billboard', [970, 250], 'div-gpt-ad-1493804392438-0').addService(googletag.pubads());
    googletag.defineSlot('/1009103/SR_Halfpage', [300, 600], 'div-gpt-ad-1493804392438-1').addService(googletag.pubads());
    var interstitialSlot = googletag.defineOutOfPageSlot('/1009103/SR_Web_Interstitial', googletag.enums.OutOfPageFormat.INTERSTITIAL);
    if (interstitialSlot) {interstitialSlot.addService(googletag.pubads());}
    googletag.defineSlot('/1009103/SR_Leaderboard', sizes, 'div-gpt-ad-1493804392438-2').addService(googletag.pubads());
    googletag.defineSlot('/1009103/SR_320x50_Leaderboard', [320, 50], 'div-gpt-ad-1565946683967-0').addService(googletag.pubads());
    // googletag.defineSlot('/1009103/SR_Mobile_Swipe_Leaderboard', [320, 220], 'div-gpt-ad-1493804392438-3').addService(googletag.pubads());
    googletag.defineSlot('/1009103/SR_Mrec', [300, 250], 'div-gpt-ad-1493804392438-4').addService(googletag.pubads());
    googletag.defineSlot('/1009103/SR_Mrec_WithinArticle_1', [300, 250], 'div-gpt-ad-1493804392438-6').addService(googletag.pubads());
    googletag.defineSlot('/1009103/SR_Mrec_WithinArticle_2', [300, 250], 'div-gpt-ad-1493804392438-7').addService(googletag.pubads());
    googletag.defineOutOfPageSlot('/1009103/SR_WideSkyscraper', 'div-gpt-ad-1494040916425-1').addService(googletag.pubads());
    googletag.defineOutOfPageSlot('/1009103/SR_Out_Of_Page', 'div-gpt-ad-1493804392438-8').addService(googletag.pubads());
    googletag.defineSlot('/1009103/SR_Pixel', [1, 1], 'div-gpt-ad-1493804392438-9').addService(googletag.pubads());
    googletag.defineSlot('/1009103/SR_InArticle_Pixel', [1, 1], 'div-gpt-ad-1495017133593-1').addService(googletag.pubads());
    googletag.defineOutOfPageSlot('/1009103/SR_InArticle_OutOfPage', 'div-gpt-ad-1495173209110-1').addService(googletag.pubads());
    // googletag.defineSlot('/1009103/SR_Skinner_Left', [160, 900], 'div-gpt-ad-1517041188625-0').addService(googletag.pubads());
    // googletag.defineSlot('/1009103/SR_Skinner_Right', [160, 900], 'div-gpt-ad-1517041188625-1').addService(googletag.pubads());
    googletag.defineSlot('/1009103/SR_Inskin', [1, 1], 'div-gpt-ad-1538375354659-0').addService(googletag.pubads()).setTargeting("InSkin", inskinTargeting);
    if (dfpTargetingParams.section.includes("homepage") || dfpTargetingParams.tags.includes("sto-overlay")) {
        googletag.defineSlot('/1009103/SR_STO', [1, 1], 'div-gpt-ad-1658471476265-0').addService(googletag.pubads());
    }
    googletag.pubads().addEventListener('slotRenderEnded', function(event) {
      // if billboard
      /*if (event.slot.getSlotElementId() == 'div-gpt-ad-1493804392438-0') {
        // if slot is filled
        if (event.isEmpty !=  true) {
          console.log('Billboard loaded');
          jQuery('#leaderboard').addClass('hidden');
          leaderboard = document.getElementById('leaderboard')
          leaderboard.style.marginBottom = "20px";
          if (inskinTargeting != 'mobile')
            leaderboard.style.display = "inline-block";
        }
      }*/
      // if leaderboard
      if (event.slot.getSlotElementId() == 'div-gpt-ad-1493804392438-2') {
        // if slot is filled
        if (event.isEmpty ==  true) {
          console.log('Leaderboard is empty');
          jQuery('#leaderboard').addClass('hidden');
          if (width > 992) {
            jQuery('#body-main-cont').css('margin-top', '64px');
          }
          // jQuery('#body-main-wrap').css('padding-top', '48px');
        } else {
          // jQuery('#wsbanner').css('margin-top', '50px');
        }
      }

      if (event.slot.getSlotElementId() == 'div-gpt-ad-1493804392438-8') {
        // if slot is filled
        if (event.isEmpty ==  true) {
          jQuery('#div-gpt-ad-1493804392438-8').addClass('hidden')
        }
      }

      if (event.slot.getSlotElementId() == 'div-gpt-ad-1493804392438-6') {
        if(!event.isEmpty){
          jQuery('#div-gpt-ad-1493804392438-6').css('padding-bottom', '15px');
        }
      }

      // if (event.slot.getSlotElementId() == 'div-gpt-ad-1538375354659-0') {
      //   // if slot is filled
      //   if (!event.isEmpty) {
      //     jQuery('#leaderboard').addClass('hidden');
      //   }
      // }

      // if mobile leaderboard
      if (event.slot.getSlotElementId() == 'div-gpt-ad-1493804392438-3') {
        // if slot is filled
        if (event.isEmpty !=  true) {
          jQuery('#main-nav-wrap').addClass('nav-unfixed');

          jQuery(window).on('scroll', function () {
            if (jQuery(window).scrollTop() > 220) {
              jQuery('#main-nav-wrap').removeClass('nav-unfixed').addClass('fixed');
            } else {
              jQuery('#main-nav-wrap').removeClass('fixed').addClass('nav-unfixed');
            }
          });
        }
      }
      var left_is_empty = false, right_is_empty = false;
      if (event.slot.getSlotElementId() == 'div-gpt-ad-1517041188625-0') {
        // if slot is filled
        if (event.isEmpty ==  true) {
          left_is_empty = true;
        }
      }

      if (event.slot.getSlotElementId() == 'div-gpt-ad-1658471476265-0') {
          if (!event.isEmpty) {
            var stoOverlay = document.getElementById('sto-overlay');
            stoOverlay.style.display = "block";
            stoOverlay.querySelector('.closebtn').addEventListener('click', function() {
              stoOverlay.style.display = "none";
            })
            setTimeout(function(){ stoOverlay.style.display = "none" }, 10000);
          }
        }
      if (event.slot.getSlotElementId() == 'div-gpt-ad-1517041188625-1') {
        // if slot is filled
        if (event.isEmpty ==  true) {
          right_is_empty = true;
        }
      }
      var both_empty = left_is_empty && right_is_empty;

      if (both_empty) {
        var skinners = document.getElementById('skinners');
        skinners.style.display = 'none';
      }
    });
    googletag.pubads()
        // .setTargeting("lotauds", lotaudsList)
        .setTargeting("section", dfpTargetingParams.section)
        .setTargeting("pos", dfpTargetingParams.pos)
        .setTargeting("tagsSR", dfpTargetingParams.tags)
        .setTargeting("emotion", "")
        .setTargeting("sentiment", "")
        .setTargeting("segment", "");

    googletag.pubads().enableLazyLoad();

    googletag.pubads().enableLazyLoad({
      fetchMarginPercent: 200,  // Fetch slots within 2 viewports.
      renderMarginPercent: 100,  // Render slots within 1 viewports.
      mobileScaling: 1.0  // Times the above values on mobile.
    });
    googletag.pubads().enableSingleRequest();
    googletag.pubads().collapseEmptyDivs(true);
    googletag.enableServices();
  });

  // Function to minimize pixel div creatives
  window.addEventListener("load", function(e) {
    // Search for all Iframes with the DFP attribute
    let iframesArr = Array.from(document.querySelectorAll('iframe[data-google-container-id]'));
    console.log("Here are the creatives currently loaded in this page:");
    console.log(iframesArr);

    iframesArr.forEach(closeParentDiv);
    function closeParentDiv(element) {
      let width = element.getAttribute('width');
      let height = element.getAttribute('height');
      if (width == 1 && height == 1) {
        // console logging targeted 1x1 creative
        console.log("Selected Pixel Creative");
        console.log(element);
        // Selecting the parentDiv (ad unit) of the 1x1 creative
        let parentDiv = element.parentElement.parentElement;
        parentDiv.style.height = 0;
        parentDiv.style.width = 0;
        parentDiv.style.margin = 0;
      }
    }
  });
</script>
  <!-- Old Facebook Pixel Code -->
<script type="72b443237b292a11638577a2-text/javascript">
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '418923988489799'); // Insert your pixel ID here.
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=418923988489799&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->

<!-- Facebook Pixel Code -->
<script type="72b443237b292a11638577a2-text/javascript">
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
 fbq('init', '864252110408074'); 
fbq('track', 'PageView');
</script>
<noscript>
 <img height="1" width="1" 
src="https://www.facebook.com/tr?id=864252110408074&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->

<!-- Begin comScore Tag -->
<script type="72b443237b292a11638577a2-text/javascript">
  var _comscore = _comscore || [];
  _comscore.push({ c1: "2", c2: "6034955" });
  (function() {
    var s = document.createElement("script"), el = document.getElementsByTagName("script")[0]; s.async = true;
    s.src = (document.location.protocol == "https:" ? "https://sb" : "http://b") + ".scorecardresearch.com/beacon.js";
    el.parentNode.insertBefore(s, el);
  })();
</script>
<noscript>
  <img src="https://sb.scorecardresearch.com/p?c1=2&c2=6034955&cv=2.0&cj=1" />
</noscript>
<!-- End comScore Tag -->

<script type="72b443237b292a11638577a2-text/javascript">
  var dataLayer = dataLayer || [];
    dataLayer.push({'errorStatus': '404'});
</script>

<!-- Google Tag Manager -->
<script type="72b443237b292a11638577a2-text/javascript">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-W7MJCLZ');</script>
<!-- End Google Tag Manager -->


<style>
	#login-list-mobile span {
		font-size: 13px !important; 
	}

	#sub-menu-mobile li {
		width:100%;
	}
  </style>
</head>

<body class="error404">

	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-W7MJCLZ"
	height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->

	<!-- Facebook Analytics -->
	<script type="72b443237b292a11638577a2-text/javascript">
	  window.fbAsyncInit = function() {
	    FB.init({
	      appId      : '1393504794101951',
	      xfbml      : true,
	      version    : 'v2.10'
	    });

	    FB.AppEvents.logPageView();

	  };

	  (function(d, s, id){
	     var js, fjs = d.getElementsByTagName(s)[0];
	     if (d.getElementById(id)) {return;}
	     js = d.createElement(s); js.id = id;
	     js.src = "https://connect.facebook.net/en_US/sdk.js";
	     fjs.parentNode.insertBefore(js, fjs);
	   }(document, 'script', 'facebook-jssdk'));
	</script>

	<div id="site" class="left relative">
		<div id="site-wrap" class="left relative">
						<div id="fly-wrap">
	<div class="fly-wrap-out">
		<div class="fly-side-wrap">
			<ul class="fly-bottom-soc left relative">
									<li class="fb-soc">
						<a href="https://facebook.com/mysiraplimau" target="_blank">
						<i class="fa fa-facebook-square fa-2"></i>
						</a>
					</li>
													<li class="twit-soc">
						<a href="http://twitter.com/mysiraplimau" target="_blank">
						<i class="fa fa-twitter fa-2"></i>
						</a>
					</li>
																	<li class="inst-soc">
						<a href="http://instagram.com/mysiraplimau" target="_blank">
						<i class="fa fa-instagram fa-2"></i>
						</a>
					</li>
																													<li class="rss-soc">
						<a href="https://siraplimau.com/feed/rss/" target="_blank">
						<i class="fa fa-rss fa-2"></i>
						</a>
					</li>
							</ul>
		</div><!--fly-side-wrap-->
		<div class="fly-wrap-in">
			<div id="fly-menu-wrap">
				<nav class="fly-nav-menu left relative">
					<div class="menu-main-menu-container"><ul id="menu-main-menu" class="menu"><li id="menu-item-11741" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-11741"><a href="/">UTAMA</a></li>
<li id="menu-item-11768" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-11768"><a href="https://siraplimau.com/./40-minggu/">40 MINGGU</a>
<ul class="sub-menu">
	<li id="menu-item-11771" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11771"><a href="https://siraplimau.com/./40-minggu/pra-hamil/">Pra-Hamil</a></li>
	<li id="menu-item-11772" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11772"><a href="https://siraplimau.com/./40-minggu/trimester-1/">Trimester 1</a></li>
	<li id="menu-item-11773" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11773"><a href="https://siraplimau.com/./40-minggu/trimester-2/">Trimester 2</a></li>
	<li id="menu-item-11774" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11774"><a href="https://siraplimau.com/./40-minggu/trimester-3/">Trimester 3</a></li>
	<li id="menu-item-11769" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11769"><a href="https://siraplimau.com/./40-minggu/bersalin-40-minggu/">Bersalin</a></li>
	<li id="menu-item-11770" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11770"><a href="https://siraplimau.com/./40-minggu/pantang-40-minggu/">Pantang</a></li>
	<li id="menu-item-19807" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-19807"><a href="https://siraplimau.com/./hospital/">Hospital</a>
	<ul class="sub-menu">
		<li id="menu-item-19808" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-19808"><a href="https://siraplimau.com/./hospital/hospital-kerajaan/">Hospital Kerajaan</a></li>
		<li id="menu-item-19809" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-19809"><a href="https://siraplimau.com/./hospital/hospital-swasta/">Hospital Swasta</a></li>
		<li id="menu-item-20136" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-20136"><a href="https://siraplimau.com/./hospital/hospital-bersalin-kuala-lumpur/">Kuala Lumpur</a></li>
		<li id="menu-item-20138" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-20138"><a href="https://siraplimau.com/./hospital/hospital-bersalin-selangor/">Selangor</a></li>
		<li id="menu-item-20137" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-20137"><a href="https://siraplimau.com/./hospital/hospita-bersalin-pulau-pinang-penang/">Pulau Pinang</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-11759" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-11759"><a href="https://siraplimau.com/./asuh/">ASUH</a>
<ul class="sub-menu">
	<li id="menu-item-11760" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11760"><a href="https://siraplimau.com/./asuh/0-6-bulan/">0-6 Bulan</a></li>
	<li id="menu-item-11763" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11763"><a href="https://siraplimau.com/./asuh/6-12-bulan/">6-12 Bulan</a></li>
	<li id="menu-item-11761" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11761"><a href="https://siraplimau.com/./asuh/1-2-tahun/">1-2 Tahun</a></li>
	<li id="menu-item-11762" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11762"><a href="https://siraplimau.com/./asuh/2-4-tahun/">2-4 Tahun</a></li>
	<li id="menu-item-11764" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11764"><a href="https://siraplimau.com/./asuh/taska-tadika/">Taska / Tadika</a></li>
</ul>
</li>
<li id="menu-item-11806" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-11806"><a href="https://siraplimau.com/./famili/">FAMILI</a>
<ul class="sub-menu">
	<li id="menu-item-11750" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11750"><a href="https://siraplimau.com/./famili/sihat/">Sihat</a></li>
	<li id="menu-item-11807" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11807"><a href="https://siraplimau.com/./famili/cantik-famili/">Cantik</a></li>
	<li id="menu-item-12025" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-12025"><a href="https://siraplimau.com/./famili/didik/">Didik</a></li>
	<li id="menu-item-12028" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-12028"><a href="https://siraplimau.com/./famili/kerjaya/">Kerjaya</a></li>
	<li id="menu-item-24330" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-24330"><a href="https://siraplimau.com/./famili/suami-isteri/">Suami Isteri</a></li>
	<li id="menu-item-11813" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11813"><a href="https://siraplimau.com/./famili/rakyat/">Rakyat</a></li>
	<li id="menu-item-19880" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-19880"><a href="https://siraplimau.com/./nostalgia/">Nostalgia</a></li>
	<li id="menu-item-17189" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-17189"><a href="https://siraplimau.com/./inspirasi/">Inspirasi</a></li>
</ul>
</li>
<li id="menu-item-14048" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-14048"><a href="https://siraplimau.com/./nur/">NUR</a></li>
<li id="menu-item-68307" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-68307"><a href="https://siraplimau.com/./dapur/">DAPUR</a></li>
<li id="menu-item-181131" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-181131"><a href="https://siraplimau.com/projekmimpi/index.html">Projek Mimpi</a></li>
<li id="menu-item-29077" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-29077"><a href="#">LAGI</a>
<ul class="sub-menu">
	<li id="menu-item-21262" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-21262"><a href="https://siraplimau.com/./percutian/">TRAVEL</a></li>
	<li id="menu-item-12051" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-12051"><a href="https://siraplimau.com/./teknologi/">TEKNOLOGI</a></li>
	<li id="menu-item-28017" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-28017"><a href="https://siraplimau.com/./deko-hias/">DEKO &#038; HIAS</a></li>
	<li id="menu-item-28018" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-28018"><a href="https://siraplimau.com/./diy-kraf/">DIY &#038; KRAF</a></li>
	<li id="menu-item-21527" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-21527"><a href="https://siraplimau.com/./inspirasi/">INSPIRASI</a></li>
	<li id="menu-item-119881" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-119881"><a href="#">LIVE RADIO</a>
	<ul class="sub-menu">
		<li id="menu-item-145786" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-145786"><a href="https://www.audioplus.audio/"><img src="https://media.siraplimau.com/2022/08/audio-plus_master.png" class="radio-logo">Get Audio+</a></li>
		<li id="menu-item-119885" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-119885"><a href="https://siraplimau.com/hotfm/"><img src="https://media.siraplimau.com/2022/08/hotfm_red.png" class="radio-logo">Hot FM</a></li>
		<li id="menu-item-119884" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-119884"><a href="https://siraplimau.com/kool101/"><img src="https://media.siraplimau.com/2023/07/no5cvXDg-logo_kool101_master-01.png" class="radio-logo">Kool 101</a></li>
		<li id="menu-item-119882" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-119882"><a href="https://siraplimau.com/8fm/"><img src="https://media.siraplimau.com/2022/08/8fm_master.png" class="radio-logo small">8FM</a></li>
		<li id="menu-item-119883" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-119883"><a href="https://siraplimau.com/flyfm/"><img src="https://media.siraplimau.com/2022/08/flyfm_master.png" class="radio-logo">Fly FM</a></li>
		<li id="menu-item-145788" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-145788"><a href="https://siraplimau.com/molek-fm/"><img src="https://media.siraplimau.com/2022/08/molekfm_master.png" class="radio-logo">Molek FM</a></li>
	</ul>
</li>
</ul>
</li>
</ul></div>				</nav>
			</div><!--fly-menu-wrap-->
		</div><!--fly-wrap-in-->
	</div><!--fly-wrap-out-->
</div><!--fly-wrap-->			<div id="head-main-wrap" class="left relative">
				<div id="head-main-top" class="relative">
																													</div><!--head-main-top-->
				<div id="main-nav-wrap" class="fixed">
					<div class="nav-out">
						<div class="nav-in">
							<div id="main-nav-cont" class="left" itemscope itemtype="http://schema.org/Organization">
								<div class="nav-logo-out">
									<!-- <a class="nav-left-wrap "> -->
										<div class="fly-but-wrap left ">
											<span></span>
											<span></span>
											<span></span>
											<span></span>
										</div><!--fly-but-wrap-->
																					<div class="nav-logo left">
																									<a itemprop="url" href="https://siraplimau.com/"><img itemprop="logo" src="https://media.siraplimau.com/wp-content/uploads/2018/12/siraplimau-logo-transp-bg.png" alt="SirapLimau.com" /></a>
																																					<h2 class="mvp-logo-title">SirapLimau.com</h2>
																							</div><!--nav-logo-->
																			<!--nav-left-wrap-->
									<div class="nav-logo-in">
										<div class="nav-menu-out">
											<div class="nav-menu-in">
												<nav class="main-menu-wrap left">
													<div class="menu-main-menu-container"><ul id="menu-main-menu-1" class="menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-11741"><a href="/">UTAMA</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-11768"><a href="https://siraplimau.com/./40-minggu/">40 MINGGU</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11771"><a href="https://siraplimau.com/./40-minggu/pra-hamil/">Pra-Hamil</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11772"><a href="https://siraplimau.com/./40-minggu/trimester-1/">Trimester 1</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11773"><a href="https://siraplimau.com/./40-minggu/trimester-2/">Trimester 2</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11774"><a href="https://siraplimau.com/./40-minggu/trimester-3/">Trimester 3</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11769"><a href="https://siraplimau.com/./40-minggu/bersalin-40-minggu/">Bersalin</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11770"><a href="https://siraplimau.com/./40-minggu/pantang-40-minggu/">Pantang</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-19807"><a href="https://siraplimau.com/./hospital/">Hospital</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-19808"><a href="https://siraplimau.com/./hospital/hospital-kerajaan/">Hospital Kerajaan</a></li>
		<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-19809"><a href="https://siraplimau.com/./hospital/hospital-swasta/">Hospital Swasta</a></li>
		<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-20136"><a href="https://siraplimau.com/./hospital/hospital-bersalin-kuala-lumpur/">Kuala Lumpur</a></li>
		<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-20138"><a href="https://siraplimau.com/./hospital/hospital-bersalin-selangor/">Selangor</a></li>
		<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-20137"><a href="https://siraplimau.com/./hospital/hospita-bersalin-pulau-pinang-penang/">Pulau Pinang</a></li>
	</ul>
</li>
</ul>
</li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-11759"><a href="https://siraplimau.com/./asuh/">ASUH</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11760"><a href="https://siraplimau.com/./asuh/0-6-bulan/">0-6 Bulan</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11763"><a href="https://siraplimau.com/./asuh/6-12-bulan/">6-12 Bulan</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11761"><a href="https://siraplimau.com/./asuh/1-2-tahun/">1-2 Tahun</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11762"><a href="https://siraplimau.com/./asuh/2-4-tahun/">2-4 Tahun</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11764"><a href="https://siraplimau.com/./asuh/taska-tadika/">Taska / Tadika</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-11806"><a href="https://siraplimau.com/./famili/">FAMILI</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11750"><a href="https://siraplimau.com/./famili/sihat/">Sihat</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11807"><a href="https://siraplimau.com/./famili/cantik-famili/">Cantik</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-12025"><a href="https://siraplimau.com/./famili/didik/">Didik</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-12028"><a href="https://siraplimau.com/./famili/kerjaya/">Kerjaya</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-24330"><a href="https://siraplimau.com/./famili/suami-isteri/">Suami Isteri</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-11813"><a href="https://siraplimau.com/./famili/rakyat/">Rakyat</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-19880"><a href="https://siraplimau.com/./nostalgia/">Nostalgia</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-17189"><a href="https://siraplimau.com/./inspirasi/">Inspirasi</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-14048"><a href="https://siraplimau.com/./nur/">NUR</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-68307"><a href="https://siraplimau.com/./dapur/">DAPUR</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-181131"><a href="https://siraplimau.com/projekmimpi/index.html">Projek Mimpi</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-29077"><a href="#">LAGI</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-21262"><a href="https://siraplimau.com/./percutian/">TRAVEL</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-12051"><a href="https://siraplimau.com/./teknologi/">TEKNOLOGI</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-28017"><a href="https://siraplimau.com/./deko-hias/">DEKO &#038; HIAS</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-28018"><a href="https://siraplimau.com/./diy-kraf/">DIY &#038; KRAF</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-21527"><a href="https://siraplimau.com/./inspirasi/">INSPIRASI</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-119881"><a href="#">LIVE RADIO</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-145786"><a href="https://www.audioplus.audio/"><img src="https://media.siraplimau.com/2022/08/audio-plus_master.png" class="radio-logo">Get Audio+</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-119885"><a href="https://siraplimau.com/hotfm/"><img src="https://media.siraplimau.com/2022/08/hotfm_red.png" class="radio-logo">Hot FM</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-119884"><a href="https://siraplimau.com/kool101/"><img src="https://media.siraplimau.com/2023/07/no5cvXDg-logo_kool101_master-01.png" class="radio-logo">Kool 101</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-119882"><a href="https://siraplimau.com/8fm/"><img src="https://media.siraplimau.com/2022/08/8fm_master.png" class="radio-logo small">8FM</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-119883"><a href="https://siraplimau.com/flyfm/"><img src="https://media.siraplimau.com/2022/08/flyfm_master.png" class="radio-logo">Fly FM</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-145788"><a href="https://siraplimau.com/molek-fm/"><img src="https://media.siraplimau.com/2022/08/molekfm_master.png" class="radio-logo">Molek FM</a></li>
	</ul>
</li>
</ul>
</li>
</ul></div>												</nav>
											</div><!--nav-menu-in-->
											<div class="nav-right-wrap relative">
												<div class="nav-search-wrap left relative">
													<span class="nav-search-but left"><i class="fa fa-search fa-2"></i></span>
													<div class="search-fly-wrap" style="max-width:260px">
														<form method="get" id="searchform" action="https://siraplimau.com/">
	<input type="text" name="s" id="s" value="Type search term and press enter" onfocus="if (!window.__cfRLUnblockHandlers) return false; if (this.value == &quot;Type search term and press enter&quot;) { this.value = &quot;&quot;; }" onblur="if (!window.__cfRLUnblockHandlers) return false; if (this.value == &quot;&quot;) { this.value = &quot;Type search term and press enter&quot;; }" data-cf-modified-72b443237b292a11638577a2-="" />
	<input type="hidden" id="searchsubmit" value="Search" />
</form>													</div><!--search-fly-wrap-->
												</div><!--nav-search-wrap-->
                                                <div class="menu-main-menu-container sso-mobile" style="float:left">
                                                    <ul id="menu-main-menu-2" class="menu" style="width:100%">
                                                        <li id="login-list-mobile" class=" menu-item menu-item-has-children " style="display: inline; float:right;">
															<span id="login-mobile" class="">
																Login
															</span>
														</li>	
														
														<li id="logout-list-mobile" class=" menu-item menu-item-has-children " style="display: none; float:right;">
															<span class="z"><i class="fa fa-user fa-2 " style="font-size:21px" ></i>
																<i class="fa fa-caret-down "></i>
															</span>
                                                            <ul id="sub-menu-mobile" class="sub-menu-dropdown" style="right:0px;width:max-content">
                                                                <li  class="menu-item "><span id="welcome-mobile" >Profile</span></li>
                                                                <li id="profile-mobile" class="menu-item "><span>Profile</span></li>
                                                                <li id="logout-mobile" class="menu-item "><span>Logout</span></li>
                                                            </ul>
                                                        </li>

																												<li id="login-list-mobile2" class="menu-item " style="display: inline;">
															<a href="https://facebook.com/mysiraplimau" target="_blank">
																<span class="nav-soc-but2"><i class="fa fa-facebook fa-2"></i></span>
															</a>
														</li>
																																											<li id="login-list-mobile2" class="menu-item " style="display: inline;">
															<a href="http://twitter.com/mysiraplimau" target="_blank">
															<span class="nav-soc-but2"><i class="fa fa-twitter fa-2"></i></span>
															</a>
															</li>
														                                                    </ul>
												</div>
						<style>
						.zero-padding{
							padding: 0px !important;
						}						
						</style>						
													<nav class="main-menu-wrap left">
														<div class="menu-main-menu-container">
															<ul id="menu-main-menu-1" class="menu">
																<li id="login-list" class="menu-item " style="padding: 0px 11px;margin-top: 5px;"><span id="login" href="#">Login</span></li>
																
																<li id="logout-list" class="menu-item menu-item-has-children " style="height:10px; display:none">
																<a id="welcome-main" href="#"><i class="fa fa-user fa-2 " style="font-size:21px" ></i></a>
																<ul class="sub-menu">
																	<li  class="menu-item "><span id="welcome" ></span></li>
																	<li id="profile" class="menu-item "><span>Profile</span></li>
																	<li id="logout" class="menu-item "><span>Logout</span></li>
																</ul>
														</li>
																												<li id="login-list" class="menu-item " style="">
																<a href="https://facebook.com/mysiraplimau" style="" class="zero-padding" target="_blank">
																<span class="nav-soc-but"><i class="fa fa-facebook fa-2"></i></span>
																</a>
															</li>
																																												<li id="login-list-mobile2" class="menu-item " style="display: inline;">
															<a href="http://twitter.com/mysiraplimau" class="zero-padding" target="_blank">
															<span class="nav-soc-but2"><i class="fa fa-twitter fa-2"></i></span>
															</a>
															</li>
														
																												</div>
													</nav>
											</div><!--nav-right-wrap-->
										</div><!--nav-menu-out-->
									</div><!--nav-logo-in-->
								</div><!--nav-logo-out-->
							</div><!--main-nav-cont-->
						</div><!--nav-in-->
					</div><!--nav-out-->
				</div><!--main-nav-wrap-->
			</div><!--head-main-wrap-->
			<!-- sso script starts  -->
			
			<script src="https://oauthjs.revmedia.my/main.min.js" type="72b443237b292a11638577a2-text/javascript"></script>
			<script type="72b443237b292a11638577a2-text/javascript">
    var mediatorInstance = Mediator.default('474382672032422', 'https://siraplimau.com/', '-sl')
    /**
     * Get the login button element
     */
    var loginBtn = document.getElementById('login')
	var logoutBtn = document.getElementById('logout')
    var welcomeDiv = document.getElementById('welcome')

	var loginList = document.getElementById('login-list')
    var logoutList = document.getElementById('logout-list')
	var profileBtn = document.getElementById('profile')

    var loginBtnM = document.getElementById('login-mobile')
    var logoutBtnM = document.getElementById('logout-mobile')
    var welcomeDivM = document.getElementById('welcome-mobile')

    var loginListM = document.getElementById('login-list-mobile')
    var logoutListM = document.getElementById('logout-list-mobile')
    var profileBtnM = document.getElementById('profile-mobile')

	var search = window.location.search
    
      loginList.style.display = "block";
      loginListM.style.display = "inline";
    

     var profile_url = mediatorInstance.getAccountURL(auto = false)

    profileBtn.onclick = function beginLogin () {
        window.location.href = profile_url
    }

    profileBtnM.onclick = function beginLogin () {
        window.location.href = profile_url
    }

    /**
         * Check if we already have existing "sessions"
         */
        mediatorInstance.getProfile()
            .then(profile => {
                if (profile === undefined) {
                    /**
                     * User not logged in yet.
                     *
                     * If login button is found, assign onclick events to the button,
                     * Event will fire mediator .beginLogin() method
                     */
                    if (loginBtn) {
                        loginBtn.onclick = function beginLogin () {
                            mediatorInstance.beginLogin()
                        }
                    }

                    if (loginBtnM) {
                        loginBtnM.onclick = function beginLogin () {
                            mediatorInstance.beginLogin()
                        }
                    }

                } else {
                    /**
                     * Existing "sessions" is available
                     *
                     * If login button is found, assign onclick events to the button,
                     * Event will fire mediator .beginLogout() method
                     */
                    if (loginBtn) {
                        if  (welcomeDiv && profile) {
                            let profileEmail = profile.email
                            let emailArray = profileEmail.split("@");
                            let welcomeText = `${emailArray[0]}`
                            if(profile.name && profile.name.trim() !== ''){
                              welcomeText = profile.name
                            }
                            welcomeDiv.innerText = `Hi ${welcomeText}`
                        }

                        loginList.style.display = "none";
                        logoutList.style.display = "block";

                        logoutBtn.onclick = beginLogout
                    }

                    if (loginBtnM) {
                        if  (welcomeDivM && profile) {
                            let profileEmail = profile.email
                            let emailArray = profileEmail.split("@");
                            let welcomeText = `${emailArray[0]}`
                            if(profile.name && profile.name.trim() !== ''){
                                welcomeText = profile.name
                            }
                            welcomeDivM.innerText = `Hi ${welcomeText}`
                        }

                        loginListM.style.display = "none";
                        logoutListM.style.display = "inline";

                        logoutBtnM.onclick = beginLogout
                    }

                }
            })

    /**
     * Check if currently on token exchange step
     */
    var search = window.location.search

    if (search.match(/code=/)) {

      /**
       * call .tokenExchange() method to grab the code to get the access_token
       * Mediator will automatically grab it from query string code
       */
        mediatorInstance.tokenExchange()
            .then(profile => {

                /**
                 * Upon success exchange, Promise will resolve the profile object with user profile
                 * detail. it will return null for any fail
                 */
                console.log('Profiledet', profile)
                if  (welcomeDiv && profile) {
                    let profileEmail = profile.email
					let emailArray = profileEmail.split("@");
					let welcomeText = `${emailArray[0]}`
					if(profile.name && profile.name.trim() !== ''){
						welcomeText = profile.name
					}
					welcomeDiv.innerText = `Hi ${welcomeText}`

                }

                if  (welcomeDivM && profile) {
                    let profileEmail = profile.email
                    let emailArray = profileEmail.split("@");
                    let welcomeText = `${emailArray[0]}`
                    if(profile.name && profile.name.trim() !== ''){
                        welcomeText = profile.name
                    }
                    welcomeDivM.innerText = `Hi ${welcomeText}`

                }

                if (profile && loginBtn) {
                    /**
                     * Change the button text and onclick events to logout
                     */
                    loginList.style.display = "none";
                    logoutList.style.display = "block";

                    window.location.href = '/'
                    logoutBtn.onclick = beginLogout

                }

                if (profile && loginBtnM) {
                    /**
                     * Change the button text and onclick events to logout
                     */
                    loginListM.style.display = "none";
                    logoutListM.style.display = "block";

                    window.location.href = '/'
                    logoutBtnM.onclick = beginLogout

                }

            })
            .catch(error => {
                console.log('login error');
                console.log(error) ;
                console.log(error.message);
            } );
    }

    function beginLogout () {
            /**
             * Upon user clicking logout, We assign login functionality back to
             * the button again.
             */

            mediatorInstance.beginLogout()
                .then(() => {
                    if  (welcomeDiv) {
                        welcomeDiv.innerText = ''
                        loginList.style.display = "block";
                        logoutList.style.display = "none";
                        loginBtn.onclick = function beginLogin () {
                            mediatorInstance.beginLogin()
                        }
                    }

                    if  (welcomeDivM) {
                        welcomeDivM.innerText = ''
                        loginListM.style.display = "block";
                        logoutListM.style.display = "none";
                        loginBtnM.onclick = function beginLogin () {
                            mediatorInstance.beginLogin()
                        }
                    }

                })
        }
</script>

			<!-- sso script end  -->

            <script type="72b443237b292a11638577a2-text/javascript">
                function toggleProfile() {
                    document.getElementById("sub-menu-mobile").classList.toggle("show");
                }

                window.onclick = function(event) {
                    if (!event.target.matches('.dropbtn')) {
                        var dropdowns = document.getElementsByClassName("sub-menu-dropdown");
                        var i;
                        for (i = 0; i < dropdowns.length; i++) {
                            var openDropdown = dropdowns[i];
                            if (openDropdown.classList.contains('show')) {
                                openDropdown.classList.remove('show');
                            }
                        }
                    }
                }

            </script>


										<div id="body-main-wrap" class="left">
							<div id="background-sidebar-wrap">
											<div id="custom_html-2" class="widget_text widget widget_custom_html"><div class="textwidget custom-html-widget"><!-- Skinners -->
<style>
  #skinners {
    width: 970px;
		margin: 0 auto;
    position: relative;
  }

  #skinnerLeft {
    position: absolute;
    width: 160px;
    height: 900px;
    left: -160px;
		top: 64px;
  }

  #skinnerRight {
    position: absolute;
    width: 160px;
    height: 900px;
    right: -160px;
		top: 64px;
  }
	
	.admin-bar #skinnerLeft,
	.admin-bar #skinnerRight {
		top: 97px;
	}
</style>
<div id="skinners"> 
  <div id="skinnerLeft">
    <!-- /1009103/SR_Skinner_Left -->
    <div id="div-gpt-ad-1517041188625-0">
    <script type="72b443237b292a11638577a2-text/javascript">
    googletag.cmd.push(function() { googletag.display('div-gpt-ad-1517041188625-0'); });
    </script>
    </div>
  </div>
  <div id="skinnerRight">
    <!-- /1009103/SR_Skinner_Right -->
    <div id="div-gpt-ad-1517041188625-1">
    <script type="72b443237b292a11638577a2-text/javascript">
    googletag.cmd.push(function() { googletag.display('div-gpt-ad-1517041188625-1'); });
    </script>
    </div>
  </div>
</div></div></div>									</div><!--background-sidebar-wrap-->
				<div id="leaderboard">
											<!-- /1009103/SR_Leaderboard -->
						<div id="div-gpt-ad-1493804392438-2">
							<script type="72b443237b292a11638577a2-text/javascript">
								googletag.cmd.push(function() { googletag.display("div-gpt-ad-1493804392438-2"); });
							</script>
						</div>
									</div>
				<div id="body-top-sidebar-wrap" class="relative">
											<div id="custom_html-5" class="widget_text widget widget_custom_html"><div class="textwidget custom-html-widget"><!-- /1009103/SR_Mobile_Swipe_Leaderboard -->
<div id="div-gpt-ad-1493804392438-3" style="max-height: 220px; margin: 0 auto">
<script type="72b443237b292a11638577a2-text/javascript">
googletag.cmd.push(function() { googletag.display("div-gpt-ad-1493804392438-3"); });
</script>
</div>

<!-- /1009103/SR_Pixel -->
<div id="div-gpt-ad-1493804392438-9" style="height:1px; width:1px;">
<script type="72b443237b292a11638577a2-text/javascript">
googletag.cmd.push(function() { googletag.display("div-gpt-ad-1493804392438-9"); });
</script>
</div>

<!-- /1009103/SR_Out_Of_Page -->
<div id="div-gpt-ad-1493804392438-8">
<script type="72b443237b292a11638577a2-text/javascript">
googletag.cmd.push(function() { googletag.display("div-gpt-ad-1493804392438-8"); });
</script>
</div>

<!-- /1009103/SR_Inskin -->
<div id="div-gpt-ad-1538375354659-0" style="height:1px; width:1px;">
<script type="72b443237b292a11638577a2-text/javascript">
googletag.cmd.push(function() { googletag.display("div-gpt-ad-1538375354659-0"); });
</script>
	<a href="http://mirziamov.ru"></a>
<a href="http://rusbankinfo.ru"></a>
	<a href="https://rusbank.net"></a>
</div></div></div><div id="custom_html-6" class="widget_text widget widget_custom_html"><div class="textwidget custom-html-widget"><!-- /1009103/SR_Billboard -->
<div id="div-gpt-ad-1493804392438-0">
<script type="72b443237b292a11638577a2-text/javascript">
googletag.cmd.push(function() { googletag.display("div-gpt-ad-1493804392438-0"); });
</script>
</div>

</div></div>									</div><!--body-top-sidebar-wrap-->

												<div class="body-main-out relative">
					<div class="body-main-in">
						<div id="body-main-cont" class="left relative">
																								  
	<!-- Generated by Taboola single post -->
	<script type="72b443237b292a11638577a2-text/javascript">
  window._taboola = window._taboola || [];
  _taboola.push({article:'auto'});
  !function (e, f, u, i) {
    if (!document.getElementById(i)){
      e.async = 1;
      e.src = u;
      e.id = i;
      f.parentNode.insertBefore(e, f);
    }
  }(document.createElement('script'),
  document.getElementsByTagName('script')[0],
  '//cdn.taboola.com/libtrc/revmediagroup-siraplimau/loader.js',
  'tb_loader_script');
  if(window.performance && typeof window.performance.mark == 'function')
    {window.performance.mark('tbl_ic');}
</script>
				
<div id="post-main-wrap" class="left relative">
	<div id="post-left-col" class="relative">
		<div id="content-area" itemprop="articleBody" class="">
			<div id="content-main" class="left relative">
				<div id="post-404" class="left relative">
					<h1>Error 404!</h1>
					<p>The page you requested does not exist or has moved.</p>
				</div><!--post-404-->
			</div><!--content-main-->
		</div><!--content-area-->
	</div><!--post-left-col-->
</div><!--post-main-wrap-->
											</div><!--body-main-cont-->
				</div><!--body-main-in-->
			</div><!--body-main-out-->
			<script type="72b443237b292a11638577a2-text/javascript">googletag.cmd.push(function() { googletag.display(interstitialSlot); });</script>
			<footer id="foot-wrap" class="left relative">
				<div id="foot-top-wrap" class="left relative">
					<div class="body-main-out relative">
						<div class="body-main-in">
							<div id="foot-widget-wrap" class="left relative">
																	<div class="foot-widget left relative">
																					<div class="foot-logo left realtive">
												<img src="https://media.siraplimau.com/wp-content/uploads/2018/12/siraplimau-logo-transp-gray.png" alt="SirapLimau.com" />
											</div><!--foot-logo-->
																				<div class="foot-info-text left relative">
											<p>Dimiliki oleh REV Media Group, sebahagian daripada Kumpulan Media Prima</p>										</div><!--footer-info-text-->
										<div class="foot-soc left relative">
											<ul class="foot-soc-list relative">
																									<li class="foot-soc-fb">
														<a href="https://facebook.com/mysiraplimau" target="_blank"><i class="fa fa-facebook-square fa-2"></i></a>
													</li>
																																					<li class="foot-soc-twit">
														<a href="http://twitter.com/mysiraplimau" target="_blank"><i class="fa fa-twitter-square fa-2"></i></a>
													</li>
																																																	<li class="foot-soc-inst">
														<a href="http://instagram.com/mysiraplimau" target="_blank"><i class="fa fa-instagram fa-2"></i></a>
													</li>
																																																																																					<li class="foot-soc-rss">
														<a href="https://siraplimau.com/feed/rss/" target="_blank"><i class="fa fa-rss-square fa-2"></i></a>
													</li>
																							</ul>
										</div><!--foot-soc-->
									</div><!--foot-widget-->
																<div id="mvp_pop_widget-3" class="widget foot-widget left relative mvp_pop_widget"><h3 class="foot-head">Trending Minggu Ini</h3>			<div class="blog-widget-wrap left relative">
				<ul class="blog-widget-list left relative">
											<li>
							<a href="https://siraplimau.com/sikap-anak/" rel="bookmark">
															<div class="blog-widget-img left relative">
									<img width="300" height="180" src="https://media.siraplimau.com/2024/05/SIKAP-ANAK-300x180.jpg" class="widget-img-main wp-post-image" alt="SIKAP ANAK" loading="lazy" srcset="https://media.siraplimau.com/2024/05/SIKAP-ANAK-300x180.jpg 300w, https://media.siraplimau.com/2024/05/SIKAP-ANAK-450x270.jpg 450w" sizes="(max-width: 300px) 100vw, 300px" />									<img width="80" height="80" src="https://media.siraplimau.com/2024/05/SIKAP-ANAK-80x80.jpg" class="widget-img-side wp-post-image" alt="SIKAP ANAK" loading="lazy" srcset="https://media.siraplimau.com/2024/05/SIKAP-ANAK-80x80.jpg 80w, https://media.siraplimau.com/2024/05/SIKAP-ANAK-150x150.jpg 150w" sizes="(max-width: 80px) 100vw, 80px" />																		<div class="feat-info-wrap">
										<div class="feat-info-views">
											<i class="fa fa-eye fa-2"></i> <span class="feat-info-text">8.7K</span>
										</div><!--feat-info-views-->
																			</div><!--feat-info-wrap-->
																										</div><!--blog-widget-img-->
														<div class="blog-widget-text left relative">
								<span class="side-list-cat">Asuh</span>
								<h2>Perangai Anak Boleh Dipengaruhi Pada Waktu Lahir, Anak Ibu Lahir Pagi, Petang atau Malam?</h2>
								<p>Kata orang sikap anak berbeza-beza mengikut waktu yang dilahirkan. Walaupun ia bukanlah satu perkara...</p>
							</div><!--blog-widget-text-->
							</a>
						</li>
											<li>
							<a href="https://siraplimau.com/jenayah-seksual-kanak-kanak/" rel="bookmark">
															<div class="blog-widget-img left relative">
									<img width="300" height="180" src="https://media.siraplimau.com/2024/05/jenayah-seksual-300x180.jpg" class="widget-img-main wp-post-image" alt="jenayah seksual" loading="lazy" srcset="https://media.siraplimau.com/2024/05/jenayah-seksual-300x180.jpg 300w, https://media.siraplimau.com/2024/05/jenayah-seksual-450x270.jpg 450w" sizes="(max-width: 300px) 100vw, 300px" />									<img width="80" height="80" src="https://media.siraplimau.com/2024/05/jenayah-seksual-80x80.jpg" class="widget-img-side wp-post-image" alt="jenayah seksual" loading="lazy" srcset="https://media.siraplimau.com/2024/05/jenayah-seksual-80x80.jpg 80w, https://media.siraplimau.com/2024/05/jenayah-seksual-150x150.jpg 150w" sizes="(max-width: 80px) 100vw, 80px" />																		<div class="feat-info-wrap">
										<div class="feat-info-views">
											<i class="fa fa-eye fa-2"></i> <span class="feat-info-text">5.6K</span>
										</div><!--feat-info-views-->
																			</div><!--feat-info-wrap-->
																										</div><!--blog-widget-img-->
														<div class="blog-widget-text left relative">
								<span class="side-list-cat">Asuh</span>
								<h2>Budak 5 Tahun Nodai Adik Kembar, Ketagih Seks Gara-Gara Ibu Kandung!</h2>
								<p>Satu lagi berita mengejutkan adalah seorang kanak-kanak dalam lingkungan usia lima tahun ditahan atas...</p>
							</div><!--blog-widget-text-->
							</a>
						</li>
											<li>
							<a href="https://siraplimau.com/hadiah-untuk-ayah/" rel="bookmark">
															<div class="blog-widget-img left relative">
									<img width="300" height="180" src="https://media.siraplimau.com/2024/05/hadiah-untuk-ayah-300x180.jpg" class="widget-img-main wp-post-image" alt="hadiah untuk ayah" loading="lazy" srcset="https://media.siraplimau.com/2024/05/hadiah-untuk-ayah-300x180.jpg 300w, https://media.siraplimau.com/2024/05/hadiah-untuk-ayah-450x270.jpg 450w" sizes="(max-width: 300px) 100vw, 300px" />									<img width="80" height="80" src="https://media.siraplimau.com/2024/05/hadiah-untuk-ayah-80x80.jpg" class="widget-img-side wp-post-image" alt="hadiah untuk ayah" loading="lazy" srcset="https://media.siraplimau.com/2024/05/hadiah-untuk-ayah-80x80.jpg 80w, https://media.siraplimau.com/2024/05/hadiah-untuk-ayah-150x150.jpg 150w" sizes="(max-width: 80px) 100vw, 80px" />																		<div class="feat-info-wrap">
										<div class="feat-info-views">
											<i class="fa fa-eye fa-2"></i> <span class="feat-info-text">5.5K</span>
										</div><!--feat-info-views-->
																			</div><!--feat-info-wrap-->
																										</div><!--blog-widget-img-->
														<div class="blog-widget-text left relative">
								<span class="side-list-cat">Famili</span>
								<h2>Ayah Tulis Diari Catat Setiap Kenangan Dengan Anak Sejak Lahir Undang Sebak..</h2>
								<p>Ayah merupakan cinta pertama buat anak-anak khususnya kepada anak perempuan. Mungkin jarang diungkapkan namun...</p>
							</div><!--blog-widget-text-->
							</a>
						</li>
									</ul>
			</div><!--blog-widget-wrap-->
		</div>							</div><!--foot-widget-wrap-->
						</div><!--body-main-in-->
					</div><!--body-main-out-->
				</div><!--foot-top-->
				<div id="foot-bot-wrap" class="left relative">
					<div class="body-main-out relative">
						<div class="body-main-in">
							<div id="foot-bot" class="left relative">
								<div class="foot-menu relative">
									<div class="menu-footer-menu-container"><ul id="menu-footer-menu" class="menu"><li id="menu-item-27089" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-27089"><a href="https://siraplimau.com/pengiklanan/">Pengiklanan</a></li>
<li id="menu-item-27091" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-27091"><a href="https://siraplimau.com/tentang-kami/">Tentang Kami</a></li>
<li id="menu-item-67644" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-67644"><a href="https://siraplimau.com/terms-and-conditions/">Terma dan Syarat</a></li>
</ul></div>								</div><!--foot-menu-->
								<div class="foot-copy relative">
									<p>Hakcipta Terpelihara © 2018 SirapLimau.com</p>
								</div><!--foot-copy-->
							</div><!--foot-bot-->
						</div><!--body-main-in-->
					</div><!--body-main-out-->
				</div><!--foot-bot-->
			</footer>
		</div><!--body-main-wrap-->
	</div><!--site-wrap-->
</div><!--site-->
<div class="fly-to-top back-to-top">
	<i class="fa fa-angle-up fa-3"></i>
	<span class="to-top-text">To Top</span>
</div><!--fly-to-top-->
<div class="fly-fade">
</div><!--fly-fade-->
<script type="72b443237b292a11638577a2-text/javascript">
  window._taboola = window._taboola || [];
  _taboola.push({flush: true});
</script>

<style>
  body.no-ads div.google-auto-placed {display: none !important;}
</style>


<script type="72b443237b292a11638577a2-text/javascript">
jQuery(document).ready(function($) {

	// Back to Top Button
    	var duration = 500;
    	$('.back-to-top').click(function(event) {
          event.preventDefault();
          $('html, body').animate({scrollTop: 0}, duration);
          return false;
	});

	// Main Menu Dropdown Toggle
	$('.menu-item-has-children a').click(function(event){
	  event.stopPropagation();
	  location.href = this.href;
  	});

	$('.menu-item-has-children').click(function(){
    	  $(this).addClass('toggled');
    	  if($('.menu-item-has-children').hasClass('toggled'))
    	  {
    	  $(this).children('ul').toggle();
	  $('.fly-nav-menu').getNiceScroll().resize();
	  }
	  $(this).toggleClass('tog-minus');
    	  return false;
  	});

	// Main Menu Scroll
	$(window).load(function(){
	  $('.fly-nav-menu').niceScroll({cursorcolor:"#888",cursorwidth: 7,cursorborder: 0,zindex:999999});
	});



$(window).load(function() {
  // The slider being synced must be initialized first
  $('.post-gallery-bot').flexslider({
    animation: "slide",
    controlNav: false,
    animationLoop: true,
    slideshow: false,
    itemWidth: 80,
    itemMargin: 10,
    asNavFor: '.post-gallery-top'
  });

  $('.post-gallery-top').flexslider({
    animation: "fade",
    controlNav: false,
    animationLoop: true,
    slideshow: false,
    	  prevText: "&lt;",
          nextText: "&gt;",
    sync: ".post-gallery-bot"
  });
});

});

</script>

<script type="72b443237b292a11638577a2-text/javascript" src='https://siraplimau.com/app/themes/flex-mag/js/scripts.js?ver=5.6.2' id='mvp-flexmag-js'></script>
<script type="72b443237b292a11638577a2-text/javascript" src='https://siraplimau.com/wp/wp-includes/js/wp-embed.min.js?ver=5.6.2' id='wp-embed-js'></script>
<script type="72b443237b292a11638577a2-text/javascript">
/* <![CDATA[ */
ai_front = {"insertion_before":"BEFORE","insertion_after":"AFTER","insertion_prepend":"PREPEND CONTENT","insertion_append":"APPEND CONTENT","insertion_replace_content":"REPLACE CONTENT","insertion_replace_element":"REPLACE ELEMENT","visible":"VISIBLE","hidden":"HIDDEN","fallback":"FALLBACK","automatically_placed":"Automatically placed by AdSense Auto ads code","cancel":"Cancel","use":"Use","add":"Add","parent":"Parent","cancel_element_selection":"Cancel element selection","select_parent_element":"Select parent element","css_selector":"CSS selector","use_current_selector":"Use current selector","element":"ELEMENT","path":"PATH","selector":"SELECTOR"};
/* ]]> */
function b2a(a){var b,c=0,l=0,f="",g=[];if(!a)return a;do{var e=a.charCodeAt(c++);var h=a.charCodeAt(c++);var k=a.charCodeAt(c++);var d=e<<16|h<<8|k;e=63&d>>18;h=63&d>>12;k=63&d>>6;d&=63;g[l++]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".charAt(e)+"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".charAt(h)+"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".charAt(k)+"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".charAt(d)}while(c<
a.length);return f=g.join(""),b=a.length%3,(b?f.slice(0,b-3):f)+"===".slice(b||3)}function a2b(a){var b,c,l,f={},g=0,e=0,h="",k=String.fromCharCode,d=a.length;for(b=0;64>b;b++)f["ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt(b)]=b;for(c=0;d>c;c++)for(b=f[a.charAt(c)],g=(g<<6)+b,e+=6;8<=e;)((l=255&g>>>(e-=8))||d-2>c)&&(h+=k(l));return h}b64e=function(a){return btoa(encodeURIComponent(a).replace(/%([0-9A-F]{2})/g,function(b,a){return String.fromCharCode("0x"+a)}))};
b64d=function(a){return decodeURIComponent(atob(a).split("").map(function(a){return"%"+("00"+a.charCodeAt(0).toString(16)).slice(-2)}).join(""))};
function ai_run_scripts(){(function(a){if("function"===typeof define&&define.amd){define(a);var c=!0}"object"===typeof exports&&(module.exports=a(),c=!0);if(!c){var e=window.Cookies,b=window.Cookies=a();b.noConflict=function(){window.Cookies=e;return b}}})(function(){function a(){for(var e=0,b={};e<arguments.length;e++){var f=arguments[e],d;for(d in f)b[d]=f[d]}return b}function c(e){function b(){}function f(h,k,g){if("undefined"!==typeof document){g=a({path:"/"},b.defaults,g);"number"===typeof g.expires&&(g.expires=new Date(1*
new Date+864E5*g.expires));g.expires=g.expires?g.expires.toUTCString():"";try{var l=JSON.stringify(k);/^[\{\[]/.test(l)&&(k=l)}catch(p){}k=e.write?e.write(k,h):encodeURIComponent(String(k)).replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g,decodeURIComponent);h=encodeURIComponent(String(h)).replace(/%(23|24|26|2B|5E|60|7C)/g,decodeURIComponent).replace(/[\(\)]/g,escape);l="";for(var n in g)g[n]&&(l+="; "+n,!0!==g[n]&&(l+="="+g[n].split(";")[0]));return document.cookie=h+"="+k+l}}
function d(h,k){if("undefined"!==typeof document){for(var g={},l=document.cookie?document.cookie.split("; "):[],n=0;n<l.length;n++){var p=l[n].split("="),m=p.slice(1).join("=");k||'"'!==m.charAt(0)||(m=m.slice(1,-1));try{var q=p[0].replace(/(%[0-9A-Z]{2})+/g,decodeURIComponent);m=(e.read||e)(m,q)||m.replace(/(%[0-9A-Z]{2})+/g,decodeURIComponent);if(k)try{m=JSON.parse(m)}catch(r){}g[q]=m;if(h===q)break}catch(r){}}return h?g[h]:g}}b.set=f;b.get=function(h){return d(h,!1)};b.getJSON=function(h){return d(h,
!0)};b.remove=function(h,k){f(h,"",a(k,{expires:-1}))};b.defaults={};b.withConverter=c;return b}return c(function(){})});AiCookies=Cookies.noConflict();
ai_check_block=function(a){if(null==a)return!0;var c=AiCookies.getJSON("aiBLOCKS");ai_debug_cookie_status="";null==c&&(c={});"undefined"!==typeof ai_delay_showing_pageviews&&(c.hasOwnProperty(a)||(c[a]={}),c[a].hasOwnProperty("d")||(c[a].d=ai_delay_showing_pageviews));if(c.hasOwnProperty(a)){for(var e in c[a]){if("x"==e){var b="",f=document.querySelectorAll('span[data-ai-block="'+a+'"]')[0];"aiHash"in f.dataset&&(b=f.dataset.aiHash);f="";c[a].hasOwnProperty("h")&&(f=c[a].h);var d=new Date;d=c[a][e]-
Math.round(d.getTime()/1E3);if(0<d&&f==b)return ai_debug_cookie_status=a="closed for "+d+" s = "+Math.round(1E4*d/3600/24)/1E4+" days",!1;ai_set_cookie(a,"x","");c[a].hasOwnProperty("i")||c[a].hasOwnProperty("c")||ai_set_cookie(a,"h","")}else if("d"==e){if(0!=c[a][e])return ai_debug_cookie_status=a="delayed for "+c[a][e]+" pageviews",!1}else if("i"==e){b="";f=document.querySelectorAll('span[data-ai-block="'+a+'"]')[0];"aiHash"in f.dataset&&(b=f.dataset.aiHash);f="";c[a].hasOwnProperty("h")&&(f=c[a].h);
if(0==c[a][e]&&f==b)return ai_debug_cookie_status=a="max impressions reached",!1;if(0>c[a][e]&&f==b){d=new Date;d=-c[a][e]-Math.round(d.getTime()/1E3);if(0<d)return ai_debug_cookie_status=a="max imp. reached ("+Math.round(1E4*d/24/3600)/1E4+" days = "+d+" s)",!1;ai_set_cookie(a,"i","");c[a].hasOwnProperty("c")||c[a].hasOwnProperty("x")||ai_set_cookie(a,"h","")}}if("ipt"==e&&0==c[a][e]&&(d=new Date,b=Math.round(d.getTime()/1E3),d=c[a].it-b,0<d))return ai_debug_cookie_status=a="max imp. per time reached ("+
Math.round(1E4*d/24/3600)/1E4+" days = "+d+" s)",!1;if("c"==e){b="";f=document.querySelectorAll('span[data-ai-block="'+a+'"]')[0];"aiHash"in f.dataset&&(b=f.dataset.aiHash);f="";c[a].hasOwnProperty("h")&&(f=c[a].h);if(0==c[a][e]&&f==b)return ai_debug_cookie_status=a="max clicks reached",!1;if(0>c[a][e]&&f==b){d=new Date;d=-c[a][e]-Math.round(d.getTime()/1E3);if(0<d)return ai_debug_cookie_status=a="max clicks reached ("+Math.round(1E4*d/24/3600)/1E4+" days = "+d+" s)",!1;ai_set_cookie(a,"c","");c[a].hasOwnProperty("i")||
c[a].hasOwnProperty("x")||ai_set_cookie(a,"h","")}}if("cpt"==e&&0==c[a][e]&&(d=new Date,b=Math.round(d.getTime()/1E3),d=c[a].ct-b,0<d))return ai_debug_cookie_status=a="max clicks per time reached ("+Math.round(1E4*d/24/3600)/1E4+" days = "+d+" s)",!1}if(c.hasOwnProperty("G")&&c.G.hasOwnProperty("cpt")&&0==c.G.cpt&&(d=new Date,b=Math.round(d.getTime()/1E3),d=c.G.ct-b,0<d))return ai_debug_cookie_status=a="max global clicks per time reached ("+Math.round(1E4*d/24/3600)/1E4+" days = "+d+" s)",!1}ai_debug_cookie_status=
"OK";return!0};
ai_check_and_insert_block=function(a,c){if(null==a)return!0;var e=document.getElementsByClassName(c);if(e.length){e=e[0];var b=e.closest(".code-block");if(ai_check_block(a)){if(ai_insert_code(e),b){var f=b.querySelectorAll(".ai-debug-block");b&&f.length&&(b.classList.remove("ai-list-block"),b.classList.remove("ai-list-block-ip"),b.style.visibility="",b.classList.contains("ai-remove-position")&&(b.style.position=""))}}else{f=e.closest("div[data-ai]");if(null!=f&&"undefined"!=typeof f.getAttribute("data-ai")){var d=
JSON.parse(b64d(f.getAttribute("data-ai")));"undefined"!==typeof d&&d.constructor===Array&&(d[1]="",f.setAttribute("data-ai",b64e(JSON.stringify(d))))}f=b.querySelectorAll(".ai-debug-block");b&&f.length&&(b.classList.remove("ai-list-block"),b.classList.remove("ai-list-block-ip"),b.style.visibility="",b.classList.contains("ai-remove-position")&&(b.style.position=""))}e.classList.remove(c)}e=document.querySelectorAll("."+c+"-dbg");b=0;for(f=e.length;b<f;b++)d=e[b],d.querySelector(".ai-status").textContent=
ai_debug_cookie_status,d.querySelector(".ai-cookie-data").textContent=ai_get_cookie_text(a),d.classList.remove(c+"-dbg")};function ai_load_cookie(){var a=AiCookies.getJSON("aiBLOCKS");null==a&&(a={});return a}function ai_get_cookie(a,c){var e="",b=ai_load_cookie();b.hasOwnProperty(a)&&b[a].hasOwnProperty(c)&&(e=b[a][c]);return e}
function ai_set_cookie(a,c,e){var b=ai_load_cookie();if(""===e){if(b.hasOwnProperty(a)){delete b[a][c];a:{c=b[a];for(f in c)if(c.hasOwnProperty(f)){var f=!1;break a}f=!0}f&&delete b[a]}}else b.hasOwnProperty(a)||(b[a]={}),b[a][c]=e;0===Object.keys(b).length&&b.constructor===Object?AiCookies.remove("aiBLOCKS"):AiCookies.set("aiBLOCKS",b,{expires:365,path:"/"});return b}
ai_get_cookie_text=function(a){var c=AiCookies.getJSON("aiBLOCKS");null==c&&(c={});var e="";c.hasOwnProperty("G")&&(e="G["+JSON.stringify(c.G).replace(/"/g,"").replace("{","").replace("}","")+"] ");var b="";c.hasOwnProperty(a)&&(b=JSON.stringify(c[a]).replace(/"/g,"").replace("{","").replace("}",""));return e+b};
ai_insert=function(d,l,v){for(var p=-1!=l.indexOf(":eq")?jQuery(l):document.querySelectorAll(l),t=0,y=p.length;t<y;t++){var b=p[t];selector_string=b.hasAttribute("id")?"#"+b.getAttribute("id"):b.hasAttribute("class")?"."+b.getAttribute("class").replace(RegExp(" ","g"),"."):"";var u=document.createElement("div");u.innerHTML=v;var m=u.getElementsByClassName("ai-selector-counter")[0];null!=m&&(m.innerText=t+1);m=u.getElementsByClassName("ai-debug-name ai-main")[0];if(null!=m){var k="";"before"==d?k=
ai_front.insertion_before:"after"==d?k=ai_front.insertion_after:"prepend"==d?k=ai_front.insertion_prepend:"append"==d?k=ai_front.insertion_append:"replace-content"==d?k=ai_front.insertion_replace_content:"replace-element"==d&&(k=ai_front.insertion_replace_element);-1==selector_string.indexOf(".ai-viewports")&&(m.innerText=k+" "+l+" ("+b.tagName.toLowerCase()+selector_string+")")}m=document.createRange();k=!0;try{var w=m.createContextualFragment(u.innerHTML)}catch(r){k=!1}"before"==d?k?b.parentNode.insertBefore(w,
b):jQuery(u.innerHTML).insertBefore(jQuery(b)):"after"==d?k?b.parentNode.insertBefore(w,b.nextSibling):jQuery(u.innerHTML).insertBefore(jQuery(b.nextSibling)):"prepend"==d?k?b.insertBefore(w,b.firstChild):jQuery(u.innerHTML).insertBefore(jQuery(b.firstChild)):"append"==d?k?b.insertBefore(w,null):jQuery(u.innerHTML).appendTo(jQuery(b)):"replace-content"==d?(b.innerHTML="",k?b.insertBefore(w,null):jQuery(u.innerHTML).appendTo(jQuery(b))):"replace-element"==d&&(k?b.parentNode.insertBefore(w,b):jQuery(u.innerHTML).insertBefore(jQuery(b)),
b.parentNode.removeChild(b))}};
ai_insert_code=function(d){function l(m,k){return null==m?!1:m.classList?m.classList.contains(k):-1<(" "+m.className+" ").indexOf(" "+k+" ")}function v(m,k){null!=m&&(m.classList?m.classList.add(k):m.className+=" "+k)}function p(m,k){null!=m&&(m.classList?m.classList.remove(k):m.className=m.className.replace(new RegExp("(^|\\b)"+k.split(" ").join("|")+"(\\b|$)","gi")," "))}if("undefined"!=typeof d){var t=!1;if(l(d,"no-visibility-check")||d.offsetWidth||d.offsetHeight||d.getClientRects().length){t=
d.getAttribute("data-code");var y=d.getAttribute("data-insertion"),b=d.getAttribute("data-selector");if(null!=t)if(null!=y&&null!=b){if(-1!=b.indexOf(":eq")?jQuery(b).length:document.querySelectorAll(b).length)ai_insert(y,b,b64d(t)),p(d,"ai-viewports")}else{y=document.createRange();b=!0;try{var u=y.createContextualFragment(b64d(t))}catch(m){b=!1}b?d.parentNode.insertBefore(u,d.nextSibling):jQuery(b64d(t)).insertBefore(jQuery(d.nextSibling));p(d,"ai-viewports")}t=!0}else u=d.previousElementSibling,
l(u,"ai-debug-bar")&&l(u,"ai-debug-script")&&(p(u,"ai-debug-script"),v(u,"ai-debug-viewport-invisible")),p(d,"ai-viewports");return t}};
ai_insert_list_code=function(d){var l=document.getElementsByClassName(d)[0];if("undefined"!=typeof l){var v=ai_insert_code(l),p=l.closest("div.code-block");if(p){v||p.removeAttribute("data-ai");var t=p.querySelectorAll(".ai-debug-block");p&&t.length&&(p.classList.remove("ai-list-block"),p.classList.remove("ai-list-block-ip"),p.style.visibility="",p.classList.contains("ai-remove-position")&&(p.style.position=""))}l.classList.remove(d);v&&ai_process_elements()}};
ai_insert_viewport_code=function(d){var l=document.getElementsByClassName(d)[0];"undefined"!=typeof l&&(ai_insert_code(l),l.classList.remove(d),setTimeout(function(){l.removeAttribute("style")},2),ai_process_elements())};ai_insert_code_by_class=function(d){var l=document.getElementsByClassName(d)[0];"undefined"!=typeof l&&(ai_insert_code(l),l.classList.remove(d))};
ai_insert_client_code=function(d,l){var v=document.getElementsByClassName(d)[0];if("undefined"!=typeof v){var p=v.getAttribute("data-code");null!=p&&ai_check_block()&&ai_check_and_insert_block()&&(v.setAttribute("data-code",p.substring(Math.floor(l/19))),ai_insert_code_by_class(d),v.remove())}};ai_process_elements_active=!1;
function ai_process_elements(){ai_process_elements_active||setTimeout(function(){ai_process_elements_active=!1;"function"==typeof ai_process_rotations&&ai_process_rotations();"function"==typeof ai_process_lists&&ai_process_lists(jQuery(".ai-list-data"));"function"==typeof ai_process_ip_addresses&&ai_process_ip_addresses(jQuery(".ai-ip-data"));"function"==typeof ai_adb_process_blocks&&ai_adb_process_blocks()},5);ai_process_elements_active=!0}
var Arrive=function(d,l,v){function p(r,c,e){b.addMethod(c,e,r.unbindEvent);b.addMethod(c,e,r.unbindEventWithSelectorOrCallback);b.addMethod(c,e,r.unbindEventWithSelectorAndCallback)}function t(r){r.arrive=k.bindEvent;p(k,r,"unbindArrive");r.leave=w.bindEvent;p(w,r,"unbindLeave")}if(d.MutationObserver&&"undefined"!==typeof HTMLElement){var y=0,b=function(){var r=HTMLElement.prototype.matches||HTMLElement.prototype.webkitMatchesSelector||HTMLElement.prototype.mozMatchesSelector||HTMLElement.prototype.msMatchesSelector;
return{matchesSelector:function(c,e){return c instanceof HTMLElement&&r.call(c,e)},addMethod:function(c,e,f){var a=c[e];c[e]=function(){if(f.length==arguments.length)return f.apply(this,arguments);if("function"==typeof a)return a.apply(this,arguments)}},callCallbacks:function(c,e){e&&e.options.onceOnly&&1==e.firedElems.length&&(c=[c[0]]);for(var f=0,a;a=c[f];f++)a&&a.callback&&a.callback.call(a.elem,a.elem);e&&e.options.onceOnly&&1==e.firedElems.length&&e.me.unbindEventWithSelectorAndCallback.call(e.target,
e.selector,e.callback)},checkChildNodesRecursively:function(c,e,f,a){for(var g=0,h;h=c[g];g++)f(h,e,a)&&a.push({callback:e.callback,elem:h}),0<h.childNodes.length&&b.checkChildNodesRecursively(h.childNodes,e,f,a)},mergeArrays:function(c,e){var f={},a;for(a in c)c.hasOwnProperty(a)&&(f[a]=c[a]);for(a in e)e.hasOwnProperty(a)&&(f[a]=e[a]);return f},toElementsArray:function(c){"undefined"===typeof c||"number"===typeof c.length&&c!==d||(c=[c]);return c}}}(),u=function(){var r=function(){this._eventsBucket=
[];this._beforeRemoving=this._beforeAdding=null};r.prototype.addEvent=function(c,e,f,a){c={target:c,selector:e,options:f,callback:a,firedElems:[]};this._beforeAdding&&this._beforeAdding(c);this._eventsBucket.push(c);return c};r.prototype.removeEvent=function(c){for(var e=this._eventsBucket.length-1,f;f=this._eventsBucket[e];e--)c(f)&&(this._beforeRemoving&&this._beforeRemoving(f),(f=this._eventsBucket.splice(e,1))&&f.length&&(f[0].callback=null))};r.prototype.beforeAdding=function(c){this._beforeAdding=
c};r.prototype.beforeRemoving=function(c){this._beforeRemoving=c};return r}(),m=function(r,c){var e=new u,f=this,a={fireOnAttributesModification:!1};e.beforeAdding(function(g){var h=g.target;if(h===d.document||h===d)h=document.getElementsByTagName("html")[0];var n=new MutationObserver(function(x){c.call(this,x,g)});var q=r(g.options);n.observe(h,q);g.observer=n;g.me=f});e.beforeRemoving(function(g){g.observer.disconnect()});this.bindEvent=function(g,h,n){h=b.mergeArrays(a,h);for(var q=b.toElementsArray(this),
x=0;x<q.length;x++)e.addEvent(q[x],g,h,n)};this.unbindEvent=function(){var g=b.toElementsArray(this);e.removeEvent(function(h){for(var n=0;n<g.length;n++)if(this===v||h.target===g[n])return!0;return!1})};this.unbindEventWithSelectorOrCallback=function(g){var h=b.toElementsArray(this);e.removeEvent("function"===typeof g?function(n){for(var q=0;q<h.length;q++)if((this===v||n.target===h[q])&&n.callback===g)return!0;return!1}:function(n){for(var q=0;q<h.length;q++)if((this===v||n.target===h[q])&&n.selector===
g)return!0;return!1})};this.unbindEventWithSelectorAndCallback=function(g,h){var n=b.toElementsArray(this);e.removeEvent(function(q){for(var x=0;x<n.length;x++)if((this===v||q.target===n[x])&&q.selector===g&&q.callback===h)return!0;return!1})};return this},k=new function(){function r(f,a,g){return b.matchesSelector(f,a.selector)&&(f._id===v&&(f._id=y++),-1==a.firedElems.indexOf(f._id))?(a.firedElems.push(f._id),!0):!1}var c={fireOnAttributesModification:!1,onceOnly:!1,existing:!1};k=new m(function(f){var a=
{attributes:!1,childList:!0,subtree:!0};f.fireOnAttributesModification&&(a.attributes=!0);return a},function(f,a){f.forEach(function(g){var h=g.addedNodes,n=g.target,q=[];null!==h&&0<h.length?b.checkChildNodesRecursively(h,a,r,q):"attributes"===g.type&&r(n,a,q)&&q.push({callback:a.callback,elem:n});b.callCallbacks(q,a)})});var e=k.bindEvent;k.bindEvent=function(f,a,g){"undefined"===typeof g?(g=a,a=c):a=b.mergeArrays(c,a);var h=b.toElementsArray(this);if(a.existing){for(var n=[],q=0;q<h.length;q++)for(var x=
h[q].querySelectorAll(f),z=0;z<x.length;z++)n.push({callback:g,elem:x[z]});if(a.onceOnly&&n.length)return g.call(n[0].elem,n[0].elem);setTimeout(b.callCallbacks,1,n)}e.call(this,f,a,g)};return k},w=new function(){function r(f,a){return b.matchesSelector(f,a.selector)}var c={};w=new m(function(){return{childList:!0,subtree:!0}},function(f,a){f.forEach(function(g){g=g.removedNodes;var h=[];null!==g&&0<g.length&&b.checkChildNodesRecursively(g,a,r,h);b.callCallbacks(h,a)})});var e=w.bindEvent;w.bindEvent=
function(f,a,g){"undefined"===typeof g?(g=a,a=c):a=b.mergeArrays(c,a);e.call(this,f,a,g)};return w};l&&t(l.fn);t(HTMLElement.prototype);t(NodeList.prototype);t(HTMLCollection.prototype);t(HTMLDocument.prototype);t(Window.prototype);l={};p(k,l,"unbindAllArrive");p(w,l,"unbindAllLeave");return l}}(window,"undefined"===typeof jQuery?null:jQuery,void 0);
var $jscomp=$jscomp||{};$jscomp.scope={};$jscomp.createTemplateTagFirstArg=function(a){return a.raw=a};$jscomp.createTemplateTagFirstArgWithRaw=function(a,k){a.raw=k;return a};$jscomp.arrayIteratorImpl=function(a){var k=0;return function(){return k<a.length?{done:!1,value:a[k++]}:{done:!0}}};$jscomp.arrayIterator=function(a){return{next:$jscomp.arrayIteratorImpl(a)}};$jscomp.makeIterator=function(a){var k="undefined"!=typeof Symbol&&Symbol.iterator&&a[Symbol.iterator];return k?k.call(a):$jscomp.arrayIterator(a)};
jQuery(function(a){function k(e){e=e.match(F);return null!=e&&1<e.length&&"string"===typeof e[1]&&0<e[1].length?e[1].toLowerCase():null}function A(e){try{var h=Date.parse(e);isNaN(h)&&(h=null)}catch(K){h=null}if(null==h&&e.includes(" ")){e=e.split(" ");try{h=Date.parse(e[0]);if(e[1].includes(":")){var t=e[1].split(":");h+=1E3*(3600*parseInt(t[0])+60*parseInt(t[1])+parseInt(t[2]))}isNaN(h)&&(h=null)}catch(K){h=null}}return h}function n(){(jQuery("#ai-iab-tcf-bar").length||jQuery(".ai-list-manual").length)&&
"function"==typeof __tcfapi&&"function"==typeof ai_load_blocks&&"undefined"==typeof ai_iab_tcf_callback_installed&&(__tcfapi("addEventListener",2,function(e,h){h&&"useractioncomplete"===e.eventStatus&&(ai_tcData=e,ai_load_blocks(),jQuery("#ai-iab-tcf-status").text("DATA LOADED"),jQuery("#ai-iab-tcf-bar").addClass("status-ok").removeClass("status-error"))}),ai_iab_tcf_callback_installed=!0)}Array.prototype.includes||(Array.prototype.includes=function(e){return!!~this.indexOf(e)});var F=/:\/\/(.[^/:]+)/i;
ai_process_lists=function(e){function h(d,b,g){if(0==d.length){if("!@!"==g)return!0;b!=g&&("true"==g.toLowerCase()?g=!0:"false"==g.toLowerCase()&&(g=!1));return b==g}if("object"!=typeof b&&"array"!=typeof b)return!1;var f=d[0];d=d.slice(1);if("*"==f)for(b=$jscomp.makeIterator(Object.entries(b)),f=b.next();!f.done;f=b.next()){if(f=$jscomp.makeIterator(f.value),f.next(),f=f.next().value,h(d,f,g))return!0}else if(f in b)return h(d,b[f],g);return!1}function t(d,b,g){if("object"!=typeof d||-1==b.indexOf("["))return!1;
b=b.replace(/]| /gi,"").split("[");return h(b,d,g)}function K(){"function"==typeof __tcfapi&&(a("#ai-iab-tcf-status").text("DETECTED"),__tcfapi("getTCData",2,function(d,b){b?(a("#ai-iab-tcf-bar").addClass("status-ok"),"tcloaded"==d.eventStatus||"useractioncomplete"==d.eventStatus?(ai_tcData=d,d.gdprApplies?a("#ai-iab-tcf-status").text("DATA LOADED"):jQuery("#ai-iab-tcf-status").text("GDPR DOES NOT APPLY"),a("#ai-iab-tcf-bar").addClass("status-ok").removeClass("status-error"),setTimeout(function(){ai_process_lists()},
10)):"cmpuishown"==d.eventStatus&&(ai_cmpuishown=!0,a("#ai-iab-tcf-status").text("CMP UI SHOWN"),a("#ai-iab-tcf-bar").addClass("status-ok").removeClass("status-error"))):(a("#ai-iab-tcf-status").text("__tcfapi getTCData failed"),a("#ai-iab-tcf-bar").removeClass("status-ok").addClass("status-error"))}))}function H(d){"function"==typeof __tcfapi?("undefined"==typeof ai_iab_tcf_callback_installed&&n(),"undefined"==typeof ai_tcData_requested&&(ai_tcData_requested=!0,K(),url_parameters_need_tcData=!0)):
d&&(a("#ai-iab-tcf-bar").addClass("status-error").removeClass("status-ok"),a("#ai-iab-tcf-status").text("MISSING: __tcfapi function not found"))}e=null==e?a("div.ai-list-data, meta.ai-list-data"):e.filter(".ai-list-data");if(e.length){e.removeClass("ai-list-data");var G=document.cookie.split(";");G.forEach(function(d,b){G[b]=d.trim()});var Q=getAllUrlParams(window.location.search);if(null!=Q.referrer)var r=Q.referrer;else r=document.referrer,""!=r&&(r=k(r));var L=window.navigator.userAgent,M=L.toLowerCase();
if("undefined"!==typeof MobileDetect)var R=new MobileDetect(L);e.each(function(){var d=a(this).closest("div.code-block"),b=!0,g=a(this).attr("referer-list");if("undefined"!=typeof g){g=b64d(g).split(",");var f=a(this).attr("referer-list-type"),l=!1;a.each(g,function(u,c){if(""==c)return!0;if("*"==c.charAt(0))if("*"==c.charAt(c.length-1)){if(c=c.substr(1,c.length-2),-1!=r.indexOf(c))return l=!0,!1}else{if(c=c.substr(1),r.substr(-c.length)==c)return l=!0,!1}else if("*"==c.charAt(c.length-
1)){if(c=c.substr(0,c.length-1),0==r.indexOf(c))return l=!0,!1}else if("#"==c){if(""==r)return l=!0,!1}else if(c==r)return l=!0,!1});switch(f){case "B":l&&(b=!1);break;case "W":l||(b=!1)}}if(b&&(g=a(this).attr("client-list"),"undefined"!=typeof g&&"undefined"!==typeof R))switch(g=b64d(g).split(","),f=a(this).attr("client-list-type"),l=!1,a.each(g,function(u,c){if(""==c)return!0;if("*"==c.charAt(0))if("*"==c.charAt(c.length-1)){if(c=c.substr(1,c.length-2).toLowerCase(),-1!=M.indexOf(c))return l=!0,
!1}else{if(c=c.substr(1).toLowerCase(),M.substr(-c.length)==c)return l=!0,!1}else if("*"==c.charAt(c.length-1)){if(c=c.substr(0,c.length-1).toLowerCase(),0==M.indexOf(c))return l=!0,!1}else if(R.is(c))return l=!0,!1}),f){case "B":l&&(b=!1);break;case "W":l||(b=!1)}var N=g=!1;if(b&&(f=a(this).attr("parameter-list"),"undefined"!=typeof f)){f=b64d(f).split(",");var v=a(this).attr("parameter-list-type"),S=[];G.forEach(function(u){u=u.split("=");try{var c=JSON.parse(decodeURIComponent(u[1]))}catch(T){c=
decodeURIComponent(u[1])}S[u[0]]=c});var x=!1,I=a(this);a.each(f,function(u,c){var T=c.split("&&");a.each(T,function(X,m){var y=!0;m=m.trim();"!!"==m.substring(0,2)&&(y=!1,m=m.substring(2));var p=m,z="!@!",U=-1!=m.indexOf("["),V=(0==m.indexOf("tcf-v2")||0==m.indexOf("euconsent-v2"))&&-1!=m.indexOf("[");-1!=m.indexOf("=")&&(z=m.split("="),p=z[0],z=z[1],U=-1!=p.indexOf("["),V=(0==p.indexOf("tcf-v2")||0==p.indexOf("euconsent-v2"))&&-1!=p.indexOf("["));if(V)a("#ai-iab-tcf-bar").show(),"object"==typeof ai_tcData?
(a("#ai-iab-tcf-bar").addClass("status-ok"),p=p.replace(/]| /gi,"").split("["),p.shift(),x=(p=h(p,ai_tcData,z))?y:!y):(I.addClass("ai-list-data"),N=!0,"function"==typeof __tcfapi?H(!1):"undefined"==typeof ai_tcData_retrying&&(ai_tcData_retrying=!0,setTimeout(function(){"function"==typeof __tcfapi?H(!1):setTimeout(function(){"function"==typeof __tcfapi?H(!1):setTimeout(function(){H(!0)},3E3)},1E3)},600)));else if(U)x=(p=t(S,p,z))?y:!y;else{var O=!1;"!@!"==z?G.every(function(W){return W.split("=")[0]==
m?(O=!0,!1):!0}):O=-1!=G.indexOf(m);x=O?y:!y}if(!x)return!1});if(x)return!1});switch(v){case "B":x&&(b=!1);break;case "W":x||(b=!1)}a(this).hasClass("ai-list-manual")&&(b?(I.removeClass("ai-list-data"),I.removeClass("ai-list-manual")):(g=!0,I.addClass("ai-list-data")));if(!g&&!N&&(f=a(this).data("debug-info"),"undefined"!=typeof f&&(f=a("."+f),0!=f.length))){var q=f.parent();q.hasClass("ai-debug-info")&&q.remove()}}q=a(this).prevAll(".ai-debug-bar.ai-debug-lists");f=""==r?"#":r;q.find(".ai-debug-name.ai-list-info").text(f).attr("title",
L);q.find(".ai-debug-name.ai-list-status").text(b?ai_front.visible:ai_front.hidden);f=!1;if(b){v=a(this).attr("scheduling-start");var B=a(this).attr("scheduling-end"),C=a(this).attr("scheduling-days");if("undefined"!=typeof v&&"undefined"!=typeof B&&"undefined"!=typeof C){f=!0;var P=parseInt(a(this).attr("scheduling-fallback")),w=parseInt(a(this).attr("gmt"));v=A(b64d(v))+w;B=A(b64d(B))+w;C=b64d(C).split(",");q=a(this).attr("scheduling-type");var D=(new Date).getTime()+w,J=new Date(D),E=J.getDay();
0==E?E=6:E--;w=D>=v&&D<B&&C.includes(E.toString());switch(q){case "B":w=!w}w||(b=!1);J=J.toISOString().split(".")[0].replace("T"," ");q=a(this).prevAll(".ai-debug-bar.ai-debug-scheduling");q.find(".ai-debug-name.ai-scheduling-info").text(J+" "+E+" current_time:"+D.toString()+"  start_date:"+v.toString()+" ="+(D>=v).toString()+" end_date:"+B.toString()+" =:"+(D<B).toString()+" days:"+C.toString()+" =:"+C.includes(E.toString()).toString());q.find(".ai-debug-name.ai-scheduling-status").text(b?ai_front.visible:
ai_front.hidden);b||0==P||(q.removeClass("ai-debug-scheduling").addClass("ai-debug-fallback"),q.find(".ai-debug-name.ai-scheduling-status").text(ai_front.fallback+"="+P))}}if(g||N)return!0;a(this).css({visibility:"",position:"",width:"",height:"","z-index":""});b?(d.css({visibility:""}),d.hasClass("ai-remove-position")&&d.css({position:""}),"undefined"!=typeof a(this).data("code")&&(b=b64d(a(this).data("code")),0!=a(this).closest("head").length?(a(this).after(b),a(this).remove()):a(this).append(b),
ai_process_element(this))):f&&!w&&0!=P?(d.css({visibility:""}),d.hasClass("ai-remove-position")&&d.css({position:""}),a(this).next(".ai-fallback").removeClass("ai-fallback"),"undefined"!=typeof a(this).data("fallback-code")?(b=b64d(a(this).data("fallback-code")),a(this).append(b),ai_process_element(this)):(a(this).hide(),d.find(".ai-debug-block").length||d.hide()),b=d.attr("data-ai"),"undefined"!==typeof b&&!1!==b&&(b=a(this).attr("fallback-tracking"),"undefined"!==typeof b&&!1!==b&&d.attr("data-ai",
b))):(a(this).hide(),d.find(".ai-debug-block").length||d.hide(),d.removeAttr("data-ai").removeClass("ai-track"),d.find(".ai-debug-block").length?(d.css({visibility:""}).removeClass("ai-close"),d.hasClass("ai-remove-position")&&d.css({position:""})):d.hide());a(this).attr("data-code","");a(this).attr("data-fallback-code","");d.removeClass("ai-list-block")})}};a(document).ready(function(e){setTimeout(function(){ai_process_lists();setTimeout(function(){n();if("function"==typeof ai_load_blocks){var h=
function(t){"cmplzEnableScripts"!=t.type&&"all"!==t.consentLevel||ai_load_blocks()};jQuery(document).on("cmplzEnableScripts",h);jQuery(document).on("cmplz_event_marketing",h)}},50);jQuery("#ai-iab-tcf-bar").click(function(){document.cookie="euconsent-v2=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;";document.cookie="__lxG__consent__v2=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;";document.cookie="__lxG__consent__v2_daisybit=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;";document.cookie=
"__lxG__consent__v2_gdaisybit=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;";document.cookie="complianz_consent_status=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;";document.cookie="cmplz_marketing=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;";document.cookie="cmplz_stats=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;";jQuery("#ai-iab-tcf-status").text("COOKIE DELETED")})},5)})});
function ai_process_element(a){setTimeout(function(){"function"==typeof ai_process_rotations_in_element&&ai_process_rotations_in_element(a);"function"==typeof ai_process_lists&&ai_process_lists(jQuery(".ai-list-data",a));"function"==typeof ai_process_ip_addresses&&ai_process_ip_addresses(jQuery(".ai-ip-data",a));"function"==typeof ai_adb_process_blocks&&ai_adb_process_blocks(a)},5)}
function getAllUrlParams(a){var k=a?a.split("?")[1]:window.location.search.slice(1);a={};if(k){k=k.split("#")[0];k=k.split("&");for(var A=0;A<k.length;A++){var n=k[A].split("="),F=void 0,e=n[0].replace(/\[\d*\]/,function(h){F=h.slice(1,-1);return""});n="undefined"===typeof n[1]?"":n[1];e=e.toLowerCase();n=n.toLowerCase();a[e]?("string"===typeof a[e]&&(a[e]=[a[e]]),"undefined"===typeof F?a[e].push(n):a[e][F]=n):a[e]=n}}return a};

ai_js_code = true;
}
function ai_wait_for_jquery(){function b(f,c){var a=document.createElement("script");a.src=f;var d=document.getElementsByTagName("head")[0],e=!1;a.onload=a.onreadystatechange=function(){e||this.readyState&&"loaded"!=this.readyState&&"complete"!=this.readyState||(e=!0,c&&c(),a.onload=a.onreadystatechange=null,d.removeChild(a))};d.appendChild(a)}window.jQuery&&window.jQuery.fn?ai_run_scripts():(ai_jquery_waiting_counter++,4==ai_jquery_waiting_counter&&b("https://siraplimau.com/wp/wp-includes/js/jquery/jquery.js?ver=3.5.1",function(){b("https://siraplimau.com/wp/wp-includes/js/jquery/jquery-migrate.min.js?ver=5.6.2",
null)}),30>ai_jquery_waiting_counter&&setTimeout(function(){ai_wait_for_jquery()},50))}ai_jquery_waiting_counter=0;ai_wait_for_jquery();

</script>
<div id="sto-overlay" class="overlay">
	<a href="javascript:void(0)" class="closebtn">SKIP THIS AD <span>&times;</span></a>
	<div class="overlay-content">
		<!-- /1009103/SR_STO -->
        <div id='div-gpt-ad-1658471476265-0'>
		<script type="72b443237b292a11638577a2-text/javascript">
			try {
				if (dfpTargetingParams.section.includes("homepage") || dfpTargetingParams.tags.includes("sto-overlay")) {
                    googletag.cmd.push(function() { googletag.display('div-gpt-ad-1658471476265-0'); });
				}
			} catch(e) {}
		</script>
		</div>
	</div>
</div>
<div id="cookie-container"></div>
<script type="72b443237b292a11638577a2-text/javascript" src="https://policy.revasia.com/cookie.consent.js"></script>

<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="72b443237b292a11638577a2-text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-588045e6fbac9ea0"></script>
<script type="72b443237b292a11638577a2-text/javascript">
    ( function ( $ ) {
        $(window).load(function() {
            var value = '26';
            var width = document.documentElement.clientWidth;
            if (width < 992) {
                // mobile
                $('#at-share-dock .at4-counter').html(value);
                $('#at-share-dock .at4-counter').css("opacity", "1");

            } else {
                // desktop
                $('#at4-share .at-custom-sidebar-count').html(value);
                $('#at4-share .at-custom-sidebar-counter').css("display", "inline-block");
            }

        });

        window.cookieConsent.init({
          message: 'This site uses functional cookies and external scripts to improve your experience. ',
          acceptText: 'Accept',
          acceptBackground: '#eb0254',
          setting: false
        });
    } )( jQuery );
</script>
<script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="72b443237b292a11638577a2-|49" defer></script></body>
</html>

<!--
Performance optimized by W3 Total Cache. Learn more: https://www.boldgrid.com/w3-total-cache/

Page Caching using memcache (SSL caching disabled) 

Served from: siraplimau.com @ 2024-05-22 11:45:30 by W3 Total Cache
-->